<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Question router
Route::match(['get','post'],'/', ['uses' => 'IndexController@main', 'as' => 'main']);
Route::match(['get','post'],'/question', ['uses' => 'IndexController@prepareTopay', 'as' => 'prepareToPay']);
Route::match(['get','post'], 'editQuestion', ['uses' => 'IndexController@editQuestion', 'as' => 'editQuestion']);
Route::match(['get','post'], 'paypal/pay',['uses' => 'PaypalController@paypal', 'as'=>'paypal']);

//Admin router
Route::get('/admin', ['middleware'=>'checkAdmin','uses' => 'AdminController@dashboard', 'as' => 'adminDashboard']);
Route::get('/admin/consultants', ['middleware'=>'checkAdmin','uses' => 'AdminController@consultants', 'as' => 'adminConsultants']);
Route::get('/admin/dashboard/{orderBy}', ['uses'=>'AdminController@dashboardOrderBy', 'as'=>'adminDashboardOrderBy']);
Route::get('/admin/dashboard/status/{status}', ['uses'=>'AdminController@orderByStatus', 'as'=>'adminDashboardOrderByStatus']);
Route::match(['get','post'],'/admin/doctorPayments',['middleware'=>'checkAdmin', 'uses' => 'AdminController@doctorPayments', 'as' => 'doctorPayments']);
Route::get('/admin/createAccount', ['middleware'=>'checkAdmin','uses' => 'AdminController@createAccount', 'as' => 'adminCreateAccount']);
Route::post('/admin/masspay', ['middleware'=>'checkAdmin','uses' => 'PaypalController@massPay', 'as' => 'massPay']);

//Doctor router
Route::get('/{id}/dashboard', ['middleware'=>'checkUser','uses' => 'UserController@dashboard', 'as' => 'dashboard']);
Route::post('/answer/doctor{doctor_id}/question{question_id}', ['middleware'=>['answer','checkUser'],'uses' => 'UserController@answer', 'as' => 'answer']);
Route::match(['get','post'],'/{id}/orders', ['middleware'=>['answer','checkUser'],'uses' => 'UserController@orders', 'as' => 'orders']);
Route::match(['get','post'],'/{id}/account', ['middleware'=>['checkUser', 'account'],'uses' => 'UserController@account', 'as' => 'account']);
Route::match(['get','post'], 'admin/clear_doctor_payment',['uses' => 'UserController@clearDoctorPayment', 'as'=>'clearDoctorPayment']);

//ajax router
Route::match(['get','post'],'/paypal',['uses' => 'PaypalController@paypal', 'as' => 'paypal']);
Route::match(['get','post'],'/paypal_doctorPayments',['uses' => 'PaypalController@doctorPayments', 'as' => 'paypal_doctorPayments']);
Route::match(['get','post'],'/admin/search/',['uses' => 'AdminController@search', 'as' => 'search']);
Route::match(['get','post'],'/admin/search/{search}/{orderBy}',['uses' => 'AdminController@OrderBySearch', 'as' => 'orderBySearch']);
Route::get('/admin/order/{orderBy}', ['uses'=>'AdminController@orderOrderBy', 'as'=>'adminOrderOrderBy']);
Route::match(['get','post'], 'question/status',['uses' => 'IndexController@changeQuestionStatus', 'as'=>'questionStatus']);
Route::match(['get','post'], 'question/statusDelete',['uses' => 'IndexController@deleteQuestionStatus', 'as'=>'deleteStatus']);
Route::match(['get','post'], 'question/cancel_status',['uses' => 'IndexController@cancelQuestionStatus', 'as'=>'cancelQuestionStatus']);
Route::match(['get','post'], 'question/check_status',['uses' => 'IndexController@CheckStatus', 'as'=>'CheckStatus']);
Route::post('doctor/active',['uses' => 'UserAjaxController@activeUser', 'as'=>'ActiveUser']);
Route::match(['get','post'], 'admin/admin_search',['uses' => 'UserAjaxController@search', 'as'=>'admin_search']);
Route::match(['get','post'], 'admin/smart_search',['uses' => 'UserAjaxController@smartSearch', 'as'=>'admin_smartSearch']);
Route::match(['get','post'], 'admin/sort_search',['uses' => 'UserAjaxController@sortSearch', 'as'=>'admin_sortSearch']);

//login and register
Route::match(['get','post'],'/loginUser', ['uses' => 'UserController@login', 'as' => 'loginUser']);
Route::post('/registration', ['middleware'=>'register', 'uses' => 'UserController@registration', 'as' => 'registration']);
Route::get('/registration', ['uses' => 'UserController@registration', 'as' => 'registration']);
Route::get('/logoutUser', ['middleware'=>'checkUser','uses' => 'UserController@loguot', 'as' => 'logoutUser']);
Route::post('/admin/register', ['middleware'=>'register','uses' => 'AdminController@createAccount', 'as' => 'register']);




//Social
Route::get('auth/facebook', ['uses' => 'AuthController@redirectToFacebookProvider','as'=>'facebook']);
Route::match(['get','post'],'auth/facebook/callback', ['uses' => 'AuthController@handleProviderCallbackFromFacebook', 'as'=>'callbackFacebook']);
Route::get('auth/github', ['uses' => 'AuthController@redirectToGithubProvider','as'=>'github']);
Route::match(['get','post'],'auth/github/callback', ['uses' => 'AuthController@handleProviderCallbackFromGithub', 'as'=>'callbackGithub']);
Route::get('auth/google', ['uses' => 'AuthController@redirectToGoogleProvider','as'=>'google']);
Route::match(['get','post'],'auth/google/callback', ['uses' => 'AuthController@handleProviderCallbackFromGoogle', 'as'=>'callbackGoogle']);
Route::get('auth/twitter', ['uses' => 'AuthController@redirectToTwitterProvider','as'=>'twitter']);
Route::match(['get','post'],'auth/twitter/callback', ['uses' => 'AuthController@handleProviderCallbackFromTwitter', 'as'=>'callbackTwitter']);
Route::get('auth/linkedin', ['uses' => 'AuthController@redirectToLinkedinProvider','as'=>'linkedin']);
Route::match(['get','post'],'auth/linkedin/callback', ['uses' => 'AuthController@handleProviderCallbackFromLinkedin', 'as'=>'callbackLinkedin']);















