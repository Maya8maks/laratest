(function ($) {
    // burger
    var burger = $('.burger');
    var menu = $('.dashboard__menu');
    var menu_question = $('.dashboard__menu_question');
    var dots = $('.dots');
    var filter = $('.dashboard__button_menu');
    var main = $('.dashboard__main');
    var doctorID = $('#doctorId').val();
    burger.on('click', function () {
        menu.toggleClass('menu_active');
        menu_question.toggleClass('menu_active');
        // main.toggleClass('dashboard__main_left');
    });

    dots.on('click', function () {
        filter.toggleClass('filter_active');
        // main.toggleClass('dashboard__main_right');
    });
    $('.table__text, .table__form, .popup_submit, .table__questions, .table__answer').hide();

    var title = $('.table__title p');
    var fade_btn = $('.fade_btn');
    var submit = $('.submit_btn');
    var complete = $('.complete');
    var answer = $('.answer');
    var doctor_complete = $('.doctor_complete');
    var inProgressConsultant = $('.inProgressConsultant');
    complete.on('click', clickComplete);
    doctor_complete.on('click', click_doctor_complete);
    inProgressConsultant.on('click', clickInProgressConsultant);
    answer.on('click', clickAnswer);// Click to complete
    title.on('click', clickToTitle);      // Click to title
    fade_btn.on('click', clickToBtn);     // Click to button
    submit.on('click', submitClick);      // Click to submit

    function clickToTitle() {
        // $(this).parent().next().next().next().stop(true).fadeToggle();
        // $(this).toggleClass('blocking');
        // if($(this).hasClass('blocking')) {
        // fade_btn.off('click', clickToBtn);
        // } else {
        // fade_btn.on('click', clickToBtn);
        // }
    }

    //function for Answer button
    function clickToBtn(e) {
        e.preventDefault();
        $(this).parent().next().stop(true).fadeToggle();
        $(this).parent().next().next().stop(true).fadeToggle();
        var that = $(this);
        if($(this).hasClass('btn_answer')) {
            $(this).text('cancel').removeClass('btn_answer').addClass('cancel');
            var id = parseInt(this.dataset.typeid);
            $.ajax({
                url: '/question/status',
                data: {
                    id: id,
                    doctor:doctorID
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                success: function(data) {
                    if(data['res']=="false"){
                        that.parent().parent().find("textarea").attr('readonly', true);
                        that.parent().parent().find("textarea").addClass('backgroundInProgress');
                        that.parent().parent().find(".table__form").append("<p class='question_doctor'>This question in progrees by " + data['doctor_name'] +"</p>");
                        that.parent().parent().find("input").attr('type', 'hidden');
                    }else{
                        that.parent().parent().find("textarea").attr('readonly', false);
                        that.parent().parent().find("textarea").removeClass('backgroundInProgress');
                        that.parent().parent().find(".question_doctor").remove();
                        that.parent().parent().find("input").attr('type', 'submit');
                    }
                },
                error: function error(err) {
                    console.log(err);
                }
            })
        }else if($(this).hasClass('cancel')){
            $(this).text('answer').removeClass('cancel').addClass('btn_answer');
            var id = parseInt(this.dataset.typeid);
            $.ajax({
                url: '/question/cancel_status',
                data: {
                    id: id
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                success: {},
                error: function error(err) {
                    console.log(err);
                }
            })
        }else if($(this).hasClass('inProgress')){
            $(this).text('Close').removeClass('inProgress').addClass('closeProgress');
                console.log('Close');
                title.off('click', clickToTitle);
        }else if($(this).hasClass('closeProgress')){
            $(this).text('In Progress').removeClass('closeProgress').addClass('inProgress');
            console.log('Progress');
        }
    }
    // function clickToBtn(e) {
    //     e.preventDefault();
    //     $(this).parent().next().stop(true).fadeToggle();
    //     $(this).parent().next().next().stop(true).fadeToggle();
    //     if ($(this).hasClass('complete')) {
    //         $(this).text('Close').removeClass('complete').addClass('closeProgress');
    //         console.log('Close');
    //         // title.off('click', clickToTitle);
    //     }
    //     else{
    //         $(this).text('In Progress').removeClass('closeProgress').addClass('complete');
    //         console.log('Progress');
    //         // title.on('click', clickToTitle);
    //     }
    // }

    //button for answer
    function submitClick(e) {
        console.log('11');
        e.preventDefault();
        var $that = $(this);
        $that.parent().parent().next().show();
        $that.parent().parent().prev().prev().children().text('complete').removeClass('cancel').addClass('complete');
        setTimeout(function () {
            $that.parent().parent().parent().hide();
            $that.parent().parent().hide();
            $that.parent().parent().prev().hide();
            $that.parent().parent().next().hide();
        }, 1500);
    }


    //button for progress
    function clickInProgressConsultant(e) {
        e.preventDefault();
        console.log('here');
        $(this).parent().next()[0].style.opacity = 1;
        $(this).parent().next().next()[0].style.opacity = 1;
    }

    //button for complete
    function clickComplete(e) {
        e.preventDefault();
        
        console.log('here');
        $(this).parent().next()[0].style.opacity = 1;
        $(this).parent().next().next()[0].style.opacity = 1;
    }

    function click_doctor_complete(e) {
        e.preventDefault();
        console.log('here');
        $(this).parent().next().stop(true).fadeToggle();
        $(this).parent().next().next().stop(true).fadeToggle();
    }

    //button for answer
    function clickAnswer(e) {
        e.preventDefault();
        var that = $(this);
        $(this).parent().next()[0].style.opacity = 1;
        $(this).parent().next().next()[0].style.opacity = 1;
        var id = parseInt(this.dataset.typeid);
        $.ajax({
            url: 'question/check_status',
            data: {
                id: id,
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'post',
            success: function(data) {
                if(data['res']=="true"){
                    that.parent().parent().find(".question_doctor").empty();
                    that.parent().parent().find(".table__answer").append("<p class='question_doctor'>This question in progrees by " + data['doctor_name'] +"</p>");
                }else{
                }
            },
            error: function error(err) {
                console.log(err);
            }
        })
    }



    // KeyPress input

    var input = $('input[name="question"]');
    var textarea = $('#counterLow');
    var count = $('.counter');
    var countTextarea = $('.counterLow');

    input.on('keydown', function() {
        count.text(this.value.length + '/120');  });

    textarea.on('keydown', function() {
        countTextarea.text(this.value.length + '/500');
    });

    // Input Readonly

    var toggled = true;
    $('.table_title').click(function() {
        toggled = !toggled;
        $(this).parent().find('input').attr('readonly', toggled ? 'readonly' : null);
        if($(this).parent().find('input').attr('readonly')) {
            $('.sbmt').fadeOut();
        } else {
            $('.sbmt').fadeIn();
        }
    });

    // sidebar style
    window.onload = function() {
        var dashboard = "[0-9]/dashboard";
        var admin = 'admin/search';
        var adminSerch = 'admin/search/[a-z.]';
        var adminDash = 'admin/dashboard/[a-z.]';
        var adminDashStatus = 'admin/dashboard/status/[a-z.]';
        var orders = "[0-9]/orders";
        var account = "[0-9]/account";
        var url = window.location.pathname;
        if( url == "/admin"  || url.search(dashboard) == 1 || url.search(adminSerch) == 1 || url.search(adminDash) == 1 || url.search(admin) ==1 || url.search(adminDashStatus) == 1){
            $('*[data-sidebar=1]').addClass('active_line');
        }
        if(url == "/admin/consultants" || url == "/admin/consultants/name" || url == "/admin/consultants/date_finish" || url.search(orders) == 1){
            $('*[data-sidebar=2]').addClass('active_line');
        }
        if(url == "/admin/createAccount" || url.search(account ) == 1){
            $('*[data-sidebar=3]').addClass('active_line');
        }
        if(url == "/admin/doctorPayments" || url.search(account ) == 1){
            $('*[data-sidebar=4]').addClass('active_line');
        }
    };


    // User activate for Admin
    $('.deactivateUser, .activeUser').click(function (event) {
        console.log('here');
        var that = $(this);
        event.preventDefault();
        var url = that.parent('form').attr('action');
        var method = that.parent('form').attr('method');
        var data = that.parent('form').serialize();
        console.log(that);
        $.ajax({
            url: url,
            data: data,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: method,
            success: function(data) {
                if(data['res']=="active"){
                    console.log(that.parent().find('input[name=action]'));
                    that.removeClass('activeUser');
                    that.addClass('deactivateUser');
                    that.val('Deactivate');
                    that.parent().find('input[name=action]').val('deactivate');

                }else if(data['res']=="deactivate"){
                    that.removeClass('deactivateUser');
                    that.addClass('activeUser');
                    that.val('Active');
                    that.parent().find('input[name=action]').val('active');
                }else{

                }
            },error: function error(err) {
                console.log(err);
            }
        })
    });
})(jQuery);

// $(document).ready(function () {
//     $('#QSubmit').click(function (event) {
//         $this = $(this);
//         event.preventDefault();
//         var url = $this.parent('form').attr('action');
//         var method = $this.parent('form').attr('method');
//         var Question = $this.parent('form').find("input[name=question]").val();
//         $('*[data-form_question_input]').css("border-color", '#808080');
//         $('*[data-form_question_error]').remove();
//         if (Question.length == 0) {
//             $this.parent('form').find("[data-form_question_label=1]")
//                 .append('<p data-form_question_error =1 ; style="font-size:12px;margin:1px;color:#ac2925">Question is Required</p>');
//             $this.parent('form').find("[data-form_question_input=1]")
//                 .css("border-color", '#ac2925');
//             return
//         }
//         if (Question.length < 3) {
//             $this.parent('form').find("[data-form_question_label=1]")
//                 .append('<p data-form_question_error =1 ; style="font-size:12px;margin:1px;color:#ac2925">Question must be more then 3 letters</p>');
//             $this.parent('form').find("[data-form_question_input=1]")
//                 .css("border-color", '#ac2925');
//             return
//         }
//         var Description = $this.parent('form').find("textarea[name=description]").val();
//         if (Description.length == 0) {
//             $this.parent('form').find("[data-form_question_label=2]")
//                 .append('<p data-form_question_error =2 ; style="font-size:12px;margin:1px;color:#ac2925">Description is Required</p>');
//             $this.parent('form').find("[data-form_question_input=2]")
//                 .css("border-color", '#ac2925');
//             return
//         }
//         if (Description.length < 15) {
//             $this.parent('form').find("[data-form_question_label=2]")
//                 .append('<p data-form_question_error =2 ; style="font-size:12px;margin:1px;color:#ac2925">Description must be more then 15 letters</p>');
//             $this.parent('form').find("[data-form_question_input=2]")
//                 .css("border-color", '#ac2925');
//             return
//         }
//         var Email = $this.parent('form').find("input[name=email]").val();
//         if (Email.length < 3) {
//             $this.parent('form').find("[data-form_question_label=3]")
//                 .append('<p data-form_question_error =3 ; style="font-size:12px;margin:1px;color:#ac2925">Email is Required</p>');
//             $this.parent('form').find("[data-form_question_input=3]")
//                 .css("border-color", '#ac2925');
//             return
//         }
//         var data = $this.parent('form').serialize();
//         var formData = new FormData($(this).get[0]);
//         $.ajax({
//             url: url,
//             headers: {
//                 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//             },
//             type: method,
//             data: formData,
//             dataType:'json',
//             async:false,
//             processData: false,
//             contentType: false,
//             success: function(response) {
//                 window.location.href = "/question/"+response['id'];
//             },
//             error: function error(err) {
//                 console.log(err);
//             }
//         });
//     });
// });
