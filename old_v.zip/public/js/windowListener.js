(function ($) {
    var doctorID = $('#doctorId').val();
    // window.addEventListener('popstate', function(e){console.log('url changed')});
    // window.addEventListener('hashchange', function(e){console.log('hash changed')});
    var oldURL = "";
    var currentURL = window.location.href;
console.log(doctorID);
    window.addEventListener('beforeunload', function(e) {
        if(currentURL == "http://lara.galactika-it.ru/"+doctorID+"/dashboard" && doctorID != null) {
            $.ajax({
                url: '/question/statusDelete',
                data: {
                    doctor: doctorID
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                success: function(data) {
                    console.log(data);
                },
                error: function error(err) {
                    console.log(err);
                }
            })
        }
    });
    window.addEventListener('onbeforeunload ', function(e) {
        if(currentURL == "http://lara.galactika-it.ru/"+doctorID+"/dashboard" && doctorID != null) {
            $.ajax({
                url: '/question/statusDelete',
                data: {
                    doctor: doctorID
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                success: function(data) {
                    console.log(data);
                },
                error: function error(err) {
                    console.log(err);
                }
            })
        }
    });
})(jQuery);