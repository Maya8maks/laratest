(function ($) {
    var that = $(this);
    var table =  $('#admin_dashboard');
    var all_search = $('#all_search');
    var timerId = null;


    $('.smartSearch').on('keyup', function (e) {
        var param = e.target.value;
        clearTimeout(timerId);
        timerId = setTimeout(function () {
            console.log('go');
            $.ajax({
                url: 'admin/smart_search',
                data: {
                    param: param,
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'post',
                success: function(data) {
                    console.log(data['questions']);
                    if(data['res'] == "success"){
                        var arr = data['questions'];
                        $('.time__sort').attr("data-like");
                        $('.time__sort').attr("data-like", param);
                        $('.time__sort').attr("data-param");
                        $('.time__sort').attr("data-param",'ASC');
                        renderPage(arr);
                    }else if(data['res'] == "false"){
                        console.log(data);
                    }
                },error: function error(err) {
                    console.log(err);
                }
            });
        },2000);

    });


    $('.all_search').click(function (event) {
        var click = $(this);
        var param = click.text();
        event.preventDefault();
        $.ajax({
            url: 'admin/admin_search',
            data: {
                param: param
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'post',
            success: function(data) {
                if(data['res'] == "success"){
                    var arr = data['questions'];
                    renderPage(arr);
                    $('.time__sort').attr("data-param");
                    $('.time__sort').attr("data-param",param);
                    $('.time__sort').attr("data-like");
                    $('.time__sort').attr("data-like", 'no');
                }else if(data['res'] == "false"){
                    console.log(data);
                }
            },error: function error(err) {
                console.log(err);
            }
        })
    });

    $('.time__sort').click(function (event) {
        var click = $(this);
        if(click.attr('data-param')){
            var param = click.attr('data-param');
        }
        else{
            var param = 'no';
        }
        if(click.attr('data-like')){
            var like = click.attr('data-like');
        }
        else{
            var like = '';
        }
        if(click.attr('data-sort')){
            var sort = click.attr('data-sort');
        }
        else{
            var sort = 'DESC';
        }
        event.preventDefault();
        console.log(param, like, sort);
        $.ajax({
            url: 'admin/sort_search',
            data: {
                param: param,
                like: like,
                sort: sort
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'post',
            success: function(data) {
                console.log(data['questions']);
                if(data['res'] == "success"){
                    var arr = data['questions'];
                    renderPage(arr);
                    $('.time__sort').attr("data-param");
                    $('.time__sort').attr("data-param",param);
                    $('.time__sort').attr("data-like");
                    $('.time__sort').attr("data-like", like);
                    $('.time__sort').attr("data-sort");
                    if(sort == 'DESC') {
                        $('.time__sort').attr("data-sort", 'ASC');
                    }else{
                        $('.time__sort').attr("data-sort", 'DESC');
                    }
                }else if(data['res'] == "false"){
                    console.log(data);
                }
            },error: function error(err) {
                console.log(err);
            }
        })
    });
    function renderPage(e) {
        table.empty();
        var ul = document.createElement('div');
         e.forEach(function(item, i, e){
            var html = '<ul class="table"><li class="table__time" style="text-align: left; width: 45%" >';
            html +=     '<p>'+item['question']+'</p>'+
                         '</li>'+
                            ' <li class="table__time">' +
                                '<span class="hours">' +
                                    item['hours']+' hours' +
                                '</span>' +
                                '<span class="min">' +
                                     item['date_add'] +' min' +
                                '</span>'+
                            '</li>'+
                            '<li class="table__time">' +
                                '<p>'+item['user_email']+'</p>'+
                            '</li>';

                        if(item['status'] == 1) {
                            var aclass = "complete";
                            var avalue = "Complete";
                        }else{
                            if (item['progress'] == 1) {
                                var aclass = "inProgressConsultant";
                                var avalue = "In Progress";
                            }else {

                                var aclass = "answer";
                                var avalue = "Question";
                            }
                        }
                html += '<li class="table__btn" style=" width: 18%;">'+
                            '<a class="'+aclass+'" href="#">'+avalue+'</a>'+
                        '</li>';
                    if(item['status'] == true) {
                        html += '<li class="table__questions" style="display: none">' +
                                    '<p>' + item['description'] + '</p>' +
                                 '</li>'+
                                 '<li class="table__answer" style="display: none">' +
                                    '<p>' + item['answer'] + '</p>';
                                    if (item['fileUrl']) {
                                        html += '<div class="OpenFile">' +
                                                    '<a href="' + item['fileUrl'] +'"  target="_blank">' +
                                                        '<span class="inputFileSpan"><i class="fas fa-paperclip"></i></span>' +
                                                    '</a>' +
                                                 '</div>';
                                    }+
                                 '</li>';
                            }else {
                                if(item['progress'] == true) {
                                html +='<li class="table__questions" style="display: none">'+
                                            '<p>'+item['description']+'</p>'+
                                        '</li>'+
                                        '<li class="table__answer" style="display: none">'+
                                            '<p>'+item['description'] +'</p>';
                                        if(item['fileUrl']) {
                                            html +='<div class="OpenFile">' +
                                                '<a href="' + item['fileUrl'] + '"target="_blank">' +
                                                    '<span class="inputFileSpan"><i class="fas fa-paperclip"></i></span>' +
                                                '</a>' +
                                            '</div>';
                                        }+
                                        '</li>';
                                }else {
                                    html += '<li class="table__questions" style="display: none" >'+
                                                '<p>'+item['description']+'</p>'+
                                            '</li>'+
                                            '<li class="table__answer" style="display: none">'+
                                                '<p>'+item['description'] +'</p>';
                                        if(item['fileUrl']) {
                                            html += '<div class="OpenFile">' +
                                                '<a href="' + item['fileUrl'] + '" target="_blank">' +
                                                    '<span class="inputFileSpan"><i class="fas fa-paperclip"></i></span>' +
                                                '</a>' +
                                            '</div>';
                                        }+
                                        '</li>';
                                }
                            }
             html +='</li></ul>';
             ul.innerHTML += html;
             });
        document.getElementById('admin_dashboard').appendChild(ul);
    }

    table.on("click", "a.answer", function(){
        $(this).parent().next().fadeToggle();
        $(this).parent().next().next().fadeToggle();
    });
    table.on("click", "a.complete", function(){
        $(this).parent().next().fadeToggle();
        $(this).parent().next().next().fadeToggle();
    });
    table.on("click", "a.inProgressConsultant", function(){
        $(this).parent().next().fadeToggle();
        $(this).parent().next().next().fadeToggle();
    });
})(jQuery);
