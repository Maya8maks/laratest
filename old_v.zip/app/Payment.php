<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'Payments';

    protected $fillable =
        [
            'id','user_id','paypal_email', 'receive', 'all_receive', 'admin_receive'
        ];

    public function doctor()
    {
        return $this->belongsTo('App\User');
    }
}
