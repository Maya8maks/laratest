<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    protected $table = 'Question';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable =
        [
            'id','description','question','user_email','user_id','date_finish','date_add','answer_id','txn_id','progressBy','progress','hours','status'
        ];


    public function doctor()
    {
        return $this->belongsTo('App\User');
    }
    public function doctorName($id){
        $user = User::find($id);
        if(isset($user)){
            return $user->name;
        }else{
            return null;
        }
    }
}
