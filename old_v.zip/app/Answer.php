<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Answer extends Model
{
    protected $table = 'Answer';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable =
        [
            'id','answer','question','description','user_email','user_id','date_add','date_finish','txn_id','hours'
        ];

    public function doctor()
    {
        return $this->belongsTo('App\User');
    }
    public function doctorName($id){
        $user = User::find($id);
        if(isset($user)){
            return $user->name;
        }else{
            return null;
        }
    }
}
