<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'Doctor';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable =
        [
            'id', 'password','name','lastname','country','user_name','profession','role','paypal_email','email','status', 'last_visit', 'active',
        ];

    public function questions()
    {
        return $this->hasMany('App\Question');
    }

    public function payment()
    {
        return $this->hasOne('App\Payment', 'user_id');
    }
    public function history()
    {
        return $this->hasMany('App\History');
    }
    public function answers()
    {
        return $this->hasMany('App\Answer');
    }
    public function failQuestions()
    {
        return $this->hasMany('App\FailQuestion');
    }
}
