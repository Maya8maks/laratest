<?php

namespace App\Http\Middleware;

use Closure;
use Validator;

class RegisterMiddlevare
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $input = $request->except('_token');
        $validator = Validator::make($input,
            [
                'name' => 'required|string|min:3',
                'lastName' => 'required|string|min:3',
                'user_name' => 'required|string|min:3|unique:Doctor',
                'country' => 'required|string|max:255',
                'password' => 'required|string|min:6|confirmed',
                'password_confirmation' => 'required_with:password|same:password|min:6',
                'profession' => 'required|string|max:255',
                'email'=>'required|email|min:3|unique:Doctor',
                'paypal_email'=>'required|min:3|email',
            ]);
        if($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }
        return $next($request);
    }
}
