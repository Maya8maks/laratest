<?php

namespace App\Http\Middleware;

use Closure;
use Validator;

class DoctorAccount
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if($request->isMethod('post'))
        {
            $input = $request->except('_token');
            $validator = Validator::make($input,
                [
                    'user_name'=>'required|min:3|unique:doctor,user_name,'.$input['id'],
                    'email'=>'required|min:3|email|unique:doctor,email,'.$input['id'],
                    'profession'=>'required|min:3',
                    'name'=>'required|min:3',
                    'lastName'=>'required|min:3',
                    'country'=>'required|min:3',
                    'paypal_email'=>'required|min:3|email',
                ]);
            if($validator->fails()){
                return redirect()->back()->withErrors($validator)->withInput();
            }
            return $next($request);
        }else
            return $next($request);
    }
}
