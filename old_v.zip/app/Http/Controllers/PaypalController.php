<?php

namespace App\Http\Controllers;

use App\History;
use App\Payment;
use Illuminate\Http\Request;
use PayPal;
use App\TempQuestion;
use App\User;
use App\Question;
use Mail;
use PayPal\Api\Currency;
use PayPal\Api\Payout;
use PayPal\Api\PayoutItem;
use PayPal\Api\PayoutSenderBatchHeader;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;
use PHPUnit\TextUI\ResultPrinter;
use Psy\Util\Json;

/**
 * Class PaypalController
 * @package App\Http\Controllers
 */
class PaypalController extends Controller
{
    /**
     * @param Request $request
     * @return $this|\Illuminate\Http\RedirectResponse
     */
    public function paypal(Request $request)
    {
        if ($_GET['amt'] == 15 and isset($_GET['cm']) and $_GET['st'] == 'Completed' and isset($_GET['tx'])) {
            $tempQuestion = TempQuestion::find($_GET['cm']);
            $question = new Question();
            $question->question = $tempQuestion->question;
            $question->description = $tempQuestion->description;
            $question->user_email = $tempQuestion->email;
            $question->user_id = null;
            $question->status = 0;
            $question->txn_id = $_GET['tx'];
            $question->date_add = $tempQuestion->date_add;
            if($tempQuestion->fileUrl) {
                $question->fileUrl = $tempQuestion->fileUrl;
            }
            $question->save();
            $emailInput =[
                'question'=>$tempQuestion->question ,
            ];
            $doctors = User::where('role', 'doctor')->get();
            foreach($doctors as $doctor){
                if($doctor->email) {
                    Mail::send('email.question', ['data' => $emailInput], function ($message) use ($doctor) {
                        $message->to($doctor->email, "")->subject('New Question');
                        $message->from('kruhlov.aleksandr@gmail.com', 'Peppling');
                    });
                }
            }
            $tempQuestion->delete();
            $request->getSession()->forget('question');
            $request->getSession()->forget('email');
            return redirect()->route('main')->withInput()->withErrors(['success' => 'success']);
        }else{
            return redirect()->back();
        }
    }

    /**
     * @param Request $request
     * @return $this
     */
    public function  doctorPayments()
    {

        if (isset($_GET['amt'])and isset($_GET['cm']) and $_GET['st'] == 'Completed' and isset($_GET['tx'])) {
            $doctor = User::find($_GET['cm']);
            $payment = $doctor->payment;
            $payment->receive = $payment->receive -  $_GET['amt'];
            $payment->all_receive = $payment->all_receive+ $_GET['amt'];

            $history = new History();
            $history->user_id = $_GET['cm'];
            $history->amount = $_GET['amt'];
            $history->type = 'payment';
            $history->save();

            if($payment->update()){
                $emailInput =[
                    'amount'=>$_GET['amt'],
                ];
                Mail::send('email.payment', ['data' => $emailInput], function ($message) use ($doctor) {
                    $message->to($doctor->email, "")->subject('Payment form Peppling');
                    $message->from('kruhlov.aleksandr@gmail.com', 'Peppling');
                });
                return redirect()->route('main')->withInput()->withErrors(['success' => 'success']);
            }else{
                redirect()->back();
            }
        }
    }

    /**
     * mass pay controller
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function massPay (Request $request){
        if($request->isMethod('post')){
            $payouts = new Payout();
            $payments = $request->input('payments');
            $clientId = 'ATsxHlCzCf_aK3XNtfPCm-BDheVUeadzDvCyh6cU1dA5mlqqr_2VwEmYFA3e07qenJaswhCHWN2_cxPm';
            $clientSecret = 'ELULEdelg2yomXMnZ3CY7DurRHdgllzQe8y5dpO9nWBqlsY8_U7ns4fI-h-tiTZnnvP_Uy1IxKQo7-e-';
            $apiContext = new ApiContext(
                new OAuthTokenCredential(
                    $clientId,
                    $clientSecret
                )
            );
            $apiContext->setConfig(
                array(
                    'mode' => 'sandbox',
                    'log.LogEnabled' => true,
                    'log.FileName' => '../PayPal.log',
                    'log.LogLevel' => 'DEBUG',
                    'cache.enabled' => true,
                )
            );

            $senderBatchHeader = new PayoutSenderBatchHeader();
            $senderBatchHeader->setSenderBatchId(uniqid())
                ->setEmailSubject("You have a payment");
            $payments = json_decode($payments, true);
            $senderItemArray = [];
            foreach( $payments as $item) {
                $senderItem = new PayoutItem();
                $senderItem->setRecipientType('Email')
                    ->setNote('payment from Peppling')
                    ->setReceiver($item['paypal_email'])
                    ->setSenderItemId("item_1" . uniqid())
                    ->setAmount(
                        new Currency('{
                        "value": '.$item['receive'].',
                        "currency":"USD"
                    }'));
                array_push ($senderItemArray,$senderItem);
            }
            $payouts->setSenderBatchHeader($senderBatchHeader);
            foreach($senderItemArray as $item){
                $payouts->addItem($item);
            }

            try {
                 $output = $payouts->create(null, $apiContext);
                 $payout_batch_id = $output->getBatchHeader()->payout_batch_id;
            } catch (Exception $ex) {
                logger($ex);
            }
            $response = $payouts->get($payout_batch_id, $apiContext, null);
            $status = $response->batch_header->batch_status;
            if($status == 'PENDING' OR $status == 'PROCESSING' OR $status == 'SUCCESS'){
                $payments = $response->items;
                foreach($payments as $item) {
                    $email = $item->payout_item->receiver;
                    $amount = $item->payout_item->amount->value;
                    $receiver = Payment::where('paypal_email', $email)->first();
                    $receiver->all_receive = $receiver->all_receive + $amount;
                    $receiver->receive = $receiver->receive - $amount;
                    $receiver->update();
                }
                return redirect()->back()->withErrors(['success' => 'success']);
            }else{
                return redirect()->back()->withErrors(['failed' => 'failed']);
            }

        }else{
            return redirect()->back();
        }
    }

}
