<?php

namespace App\Http\Controllers;

use App\Answer;
use App\Doctor;
use App\FailQuestion;
use App\Payment;
use App\User;
use App\Question;
use App\Value;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Storage;

/**
 * Class AdminController
 * @package App\Http\Controllers
 */
class AdminController extends Controller
{
    /**
     * Controller for admin dashboard page
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function dashboard()
    {
        $question = Question::all();
        $answer = Answer::all();
        $failQuestion = FailQuestion::all();
        $questions = $question->merge($answer)->merge($failQuestion);
        $data=[
            'questions' => $questions->sortByDesc('date_add'),
            'orderByDay' => 'date_down',
            'orderByName' => 'name_up',
            'dashboard' => true
        ];
        return view('admin_index',$data);
    }

    /**
     * Controller for create account page
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function createAccount(Request $request){
        if($request->isMethod('post'))
        {
            $data =[
                'name' => $request['name'],
                'email'=>$request['user_email'],
                'lastname' => $request['lastName'],
                'user_name' => $request['user_name'],
                'country' => $request['country'],
                'profession' => $request['profession'],
                'password' => Hash::make($request['password']),
                'role'=>'doctor',
                'paypal_email'=> $request['paypal_email'],
                'status'=>1,
                'money'=>0,
            ];
            $doctor = new User();
           if($doctor->fill($data)->save()){
               $payment = new Payment();
               $payment_data = [
                   'user_id'=>$doctor->id,
                   'paypal_email'=> $request['paypal_email'],
                   'receive' => 0,
                   'all_receive' => 0
               ];
               $payment->fill($payment_data)->save();
           }
            /**
             * save image if exist
             */
            if(Input::file('image')->isValid()) {
                $file = Input::file('image');
                $ext = $file->guessClientExtension();
                $name = 'avatar.'.$ext;
                $file->storeAs('/public/doctor/'. $doctor->id, $name);
                $doctor->img = $name ;
                $doctor->update();
            }

            return redirect()->back();

        }elseif ($request->isMethod('get'))
        {
            return view('admin_account');

        }else{
            return redirect()->back();
        }
    }


    /**
     * Controller for consultants page
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function consultants(){
        $doctors = User::all();
        $data = [
            'doctors' => $doctors
        ];
        return view('admin_consultants', $data);
    }

    /**
     * Controller for payments page
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function doctorPayments (){

        $doctors = User::all();
        $payments = Payment::where('receive', '>', 0)->get();
        $value = Value::where('title', 'doctor_amount')->first();
        $data=[
            'doctors' => $doctors,
            'value' => $value,
            'payments' => $payments
        ];
        return view('admin_payments', $data);
    }
}
