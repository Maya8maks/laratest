<?php

namespace App\Http\Controllers;

use App\Answer;
use App\History;
use App\Payment;
use App\User;
use App\Question;
use App\Value;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Mail;
use Validator;

/**
 * Class UserController
 * @package App\Http\Controllers
 */
class UserController extends Controller
{
    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function dashboard(Request $request, $id)
    {
        if($request->isMethod('post'))
        {

        }else {
            $doctor = User::find($id);
            $question = Question::all();
            $payment = $doctor->payment;
            $data = [
                'doctor' => $doctor,
                'questions' => $question,
                'payment' => $payment,
                'currentTime' => Carbon::now()->format('Y-m-d H:i:s')
            ];

            return view('doctor_index', $data);
        }
    }

    /**
     * @param Request $request
     * @param $doctor_id
     * @param $question_id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function answer(Request $request, $doctor_id, $question_id)
    {
        if($request->isMethod('post'))
        {
            $input = $request->except('_token');
            $question = Question::find($question_id);
            $doctor = User::find($doctor_id);
            $value = Value::where('title', 'doctor_amount')->first();
            $valueDoctor = Value::where('title', 'cost')->first();
            $payment = $doctor->payment;
            $emailInput =[
                'question_id'=>$question_id,
                'answer'=>$input['text'],
                'question'=>$question->question,
                'doctor_name'=>$doctor->name,
                'doctor_lastName'=>$doctor->lastname,
            ];
            Mail::send('email.email', ['data'=>$emailInput], function($message) use ($question){
                $message->to($question->user_email,"")->subject('Answer from Peppling');
                $message->from('kruhlov.aleksandr@gmail.com', 'Peppling');
            });
            if (Mail::failures()) {
                redirect()->back();
            }
            $payment = $doctor->payment;
            if(!isset($payment)){
                $payment = new Payment();
                $payment->user_id= $doctor_id;
                $payment->paypal_email= '';
                $payment->receive = $value->value;
                $payment->admin_receive = $payment->admin_receive + ($valueDoctor->value - $value->value);
                $payment->save();
            }else{
                $oldAmound = $payment->receive;
                $payment->receive =$oldAmound + $value->value;
                $payment->all_receive = $payment->all_receive + $value->value;
                $payment->admin_receive = $payment->admin_receive + ($valueDoctor->value - $value->value);
                $payment->update();
            }
            $history = new History();
            $history->user_id = $doctor->id;
            $history->question_id = $question_id;
            $history->amount = $value->value;
            $history->type = 'answer';
            $history->save();

            $answer = new Answer();
            $data=[
                'question'=>$question->question,
                'answer'=>$input['text'],
                'description'=>$question->description,
                'user_email'=>$question->user_email,
                'user_id'=>$question->user_id,
                'txn_id'=>$question->txn_id,
                'date_add'=>$question->date_add,
                'fileUrl' => $question->fileUrl,
                'date_finish'=>Carbon::now()->format('Y-m-d H:i:s')
            ];
            if($answer->fill($data)->save()){
                $question->delete();
            }
            return redirect()->route('dashboard',array('id'=>$doctor_id));
        }else{
            redirect()->back();
        }
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function orders($id){
        $doctor = User::find($id);
        $payment = $doctor->payment;
        $data=[
            'doctor'=>$doctor,
            'payment' => $payment
        ];
        return view('doctor_orders', $data);
    }

    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function account(Request $request, $id)
    {
        if($request->isMethod('post'))
        {
            $input = $request->except('_token');
            $doctor = User::find($id);
            $payment = $doctor->payment;
            $data=[
              'name'=>$input['name'],
              'lastname'=>$input['lastName'],
              'country'=>$input['country'],
              'user_name'=>$input['user_name'],
              'profession'=>$input['profession'],
              'status'=>$input['status'],
              'email'=>$input['email'],
              'payment' => $payment
            ];
            $doctor->fill($data)->update();
            $paypal_data=[
                'paypal_email' => $input['paypal_email']
            ];
            $payment->fill($paypal_data)->update();
            return redirect()->back();
        }else{
            $doctor = User::find($id);
            $payment = $doctor->payment;

            $data = [
                'doctor' => $doctor,
                'payment' => $payment
            ];
            return view('doctor_account', $data);
        }
    }

    /**
     * @param Request $request
     * @return $this|\Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Illuminate\View\View
     */
    public function login(Request $request)
    {
        if($request->isMethod('get'))
        {
            return view('auth.login');

        }
        elseif ($request->isMethod('post'))
        {

            $input = $request->except('_token');
            $rules = array(
                'userName' => 'required|min:3',
                'password' => 'required|min:6'
            );
            $validator = Validator::make($input, $rules);
            if ($validator->fails()) {
                return redirect()->back()->withInput($request->input())->withErrors($validator);
            } else {
                $userdata = array(
                    'user_name' => $input['userName'],
                    'password'  => $input['password']
                );
                if (Auth::attempt($userdata)) {
                    $user = Auth::user();
                    if($user->active == false){
                        return redirect()->back()->withInput()->withErrors(['notActive' => 'your account not active']);
                    }
                    if($user->role == "doctor")
                    {
                        $user->last_visit = Carbon::now()->format('Y-m-d H:i:s');
                        $user->update();
                        return redirect('/'.Auth::id().'/dashboard');
                    }elseif ($user->role == "admin")
                    {
                        return redirect('/admin');
                    }else {
                        return redirect('/');
                    }
                }else{
                    return redirect()->back()->withInput()->withErrors(['bedUser'=>'bed user name or password']);
                }
            }

        }else{
            return redirect('main');
        }
    }

    /**
     * @return \Illuminate\Http\RedirectResponse
     */
    public function loguot(){
        Auth::logout();
        return redirect()->route('main');
    }

    /**
     * @param Request $request
     * @return $this|\Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function registration(Request $request){

        if($request->isMethod('post'))
        {
            $data =[
                'name' => $request['name'],
                'email'=>$request['email'],
                'lastname' => $request['lastName'],
                'user_name' => $request['user_name'],
                'country' => $request['country'],
                'profession' => $request['profession'],
                'password' => Hash::make($request['password']),
                'role'=>'doctor',
                'last_visit' =>  Carbon::now()->format('Y-m-d H:i:s'),
                'status'=>1,
            ];
            $doctor = new User();
            if($doctor->fill($data)->save()){
                $payment = new Payment();
                $payment_data = [
                    'user_id'=>$doctor->id,
                    'paypal_email'=> $request['paypal_email'],
                    'receive' => 0,
                    'all_receive' => 0
                ];
                $payment->fill($payment_data)->save();
                $this->emailNewRegister($doctor);
            }
            if(Input::has('image')) {
                if(Input::file('image')->isValid()) {
                    $file = Input::file('image');
                    $ext = $file->guessClientExtension();
                    $name = 'avatar.' . $ext;
                    $file->storeAs('/public/doctor/' . $doctor->id, $name);
                    $doctor->img = $name;
                    $doctor->update();
                }
            }
            return redirect()->route('main')->withInput()->withErrors(['register' => 'register']);

        }elseif ($request->isMethod('get'))
        {
            return view('auth.register');

        }else{
            return redirect()->back();
        }
    }

    /**
     * @param Doctor $doctor
     */
    public function emailNewRegister(Doctor $doctor){
        $emailInput =[
            'doctor_name'=>$doctor->name,
            'doctor_lastName'=>$doctor->lastname,
        ];
        $admins = Doctor::where('role', 'admin')->get();
        foreach($admins as $admin) {
            Mail::send('register.email', ['data' => $emailInput], function ($message) use ($admin) {
                $message->to($admin->user_email, "")->subject('Answer from Peppling');
                $message->from('kruhlov.aleksandr@gmail.com', 'Peppling');
            });
        }
    }

    /**
     * @param Request $request
     * @return $this
     */
    public function clearDoctorPayment (Request $request){
        $doctorId = $request->get('doctorId');
        $amount = $request->get('amount');
        $doctor = Payment::where('user_id', $doctorId)->first();
        if(isset($doctor)){
            $doctor->receive =  $doctor->receive-$amount;
            $doctor->all_receive = $doctor->all_receive+ $amount;
            $doctor->update();
            $history = new History();
            $history->user_id = $doctorId;
            $history->amount = $amount;
            $history->type = 'payment';
            $history->save();
            return redirect()->back()->withInput()->withErrors(['success' => 'success']);
        }
        return redirect()->back()->withInput()->withErrors(['bd' => 'bed conection']);
    }
}
