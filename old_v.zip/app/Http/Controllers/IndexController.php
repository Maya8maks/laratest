<?php

namespace App\Http\Controllers;

use App\Doctor;
use App\DoctorNumber;
use App\Emails;
use App\Question;
use App\TempQuestion;
use App\User;
use App\Value;
use Carbon\Carbon;
use Faker\Provider\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;
use Validator;
use Newsletter;

/**
 * Class IndexController
 * @package App\Http\Controllers
 */
class IndexController extends Controller
{
    /**
     * Controller for main page
     *
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function main (Request $request)
    {
        $id = $request->getSession()->get('id');
        if($request->isMethod('post')) {
            return $this->postMethod($request);
        } elseif(isset($id)) {
            return $this->backToMain($request, $id);
        } else {
            return view('index');
        }
    }
    /**
     * Controller for redirect user to index page with input question
     * @param $question
     * @param $email
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function editQuestion ($question, $email)
    {
        if(isset($question) and isset($email)) {
            $tempQuestion = TempQuestion::where('question', $question)->where('email', $email)->first();
            if(isset($tempQuestion)) {
                $description = $tempQuestion->description;
                TempQuestion::where('question', $question)->where('email', $email)->delete();
                $data = [
                    'question' => $question,
                    'email' => $email,
                    'description' => $description
                ];
                return view('index', $data);
            } else {
                return view('index');
            }
        } else {
            return view('index');
        }
    }

    /**
     * Controller for page prepare to pay
     * @param Request $request
     * @return $this|\Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function postMethod (Request $request)
    {
        $input = $request->except('_token');
        $rules = array(
            'question' => 'required|min:3',
            'description' => 'required|min:15',
            'email' => 'required|min:3'
        );
        /**
         * validate question from user
         */
        $validator = Validator::make($input, $rules);
        if($validator->fails()) {
            return redirect()->back()->withInput($request->input())->withErrors($validator);
        }
        if(!Newsletter::isSubscribed($request->get('email'))){
            Newsletter::subscribe($request->get('email'));
        }
        $email = Emails::where('email', $request->get('email'))->first();
        if(!$email) {
            $newEmail = new Emails();
            $newEmail->email = $request->get('email');
            $newEmail->save();
        }
        $data =
            [
                'question' => $request->get('question'),
                'description' => $request->get('description'),
                'email' => $request->get('email'),
                'fileUrl' => null,
                'date_add' => Carbon::now()->format('Y-m-d H:i:s')
            ];
        $question = new TempQuestion();
        if($question->fill($data)->save()) {
            if(Input::file('file')) {
                if(Input::file('file')->isValid()) {
                    mkdir("img/question/".$question->id.'/');
                    $target_dir = "img/question/".$question->id.'/';
                    $target_file = $target_dir . basename($_FILES["file"]["name"]);
                    move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
                    $question->fileUrl = $target_file;
                    $question->update();
                }
            }
            $value = Value::where('title', 'cost')->first();
            $data = [
                'question' => $request->get('question'),
                'discription' => $request->get('description'),
                'email' => $request->get('email'),
                'id' => $question->id,
                'value' => $value
            ];
            return view('prepareToPay', $data);
        } else {
            return redirect()->back();
        }
    }

    /**
     * @param $request
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function backToMain ($request, $id)
    {
        $tempQuestion = TempQuestion::where('id', $id)->first();
        $request->getSession()->forget('id');
        if(isset($tempQuestion)) {
            $data = [
                'question' => $tempQuestion->question,
                'email' => $tempQuestion->email,
                'description' => $tempQuestion->description
            ];
            if($tempQuestion->fileUrl) {
                unlink(storage_path('app/public/upload/' . $tempQuestion->id . '/' . $tempQuestion->fileUrl));
                rmdir(storage_path('app/public/upload/' . $tempQuestion->id));
            }
            $tempQuestion->delete();
            return view('index', $data);
        } else {
            return view('index');
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|null
     */
    public function changeQuestionStatus (Request $request)
    {
        $id = $request->get('id');
        $doctorID = $request->get('doctor');
        if(isset($id)) {
            $question = Question::find($id);
            if($question->progress == 0) {
                $question->progress = 1;
                $question->progressBy = $doctorID;
                $question->update();
                $data['res'] = "true";
            } else {
                $doctor_name = $question->doctorName($question->progressBy);
                $data['res'] = "false";
                $data['doctor_name'] = $doctor_name;
            }
            return response()->json($data);
        } else {
            return null;
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|null
     */
    public function cancelQuestionStatus (Request $request)
    {
        $id = $request->get('id');
        if(isset($id)) {
            $question = Question::find($id);
            if($question->progress == 1) {
                $question->progress = 0;
                $question->progressBy = 0;
                $question->update();
                $data['res'] = "true";
            } else {
                $data['res'] = "false";
            }
            return response()->json($data);
        } else {
            return null;
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteQuestionStatus (Request $request)
    {
        $id = $request->get('doctor');
        if(isset($id)) {
            $questions = Question::where('progressBy', $id)->get();
            if(isset($questions)) {
                if($questions->count() > 0) {
                    foreach($questions as $question) {
                        $question->progress = 0;
                        $question->progressBy = 0;
                        $question->update();
                        $data['res'] = "true";
                        return response()->json($data);
                    }
                }
                $data['res'] = "null";
                return response()->json($data);
            }
            $data['res'] = "null";
            return response()->json($data);
        }
        return response()->json($data);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function CheckStatus(Request $request){
        $id = $request->get('id');
        if(isset($id)){
            $question = Question::find($id);
            if(isset($question)){
                if($question->progress == 1){
                    $doctor = User::find($question->progressBy);
                    if(isset($doctor)){
                        $data['res'] = "true";
                        $data['doctor_name'] = $doctor->name;
                        return response()->json($data);
                    }
                }
            }
        }else{
            $data['res'] = "null";
            return response()->json($data);
        }
        $data['res'] = "null";
        return response()->json($data);
    }
}
