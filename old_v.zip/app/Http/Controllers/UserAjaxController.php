<?php

namespace App\Http\Controllers;

use App\Answer;
use App\FailQuestion;
use App\Payment;
use App\Question;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;

/**
 * Class UserAjaxController
 * @package App\Http\Controllers
 */
class UserAjaxController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function ActiveUser(Request $request){
        $id = $request->get('id');
        $action = $request->get('action');
        if(isset($id) and isset($action)){
            if($action == 'deactivate') {
                $doctor = User::find($id);
                $doctor->active = 0;
                if($doctor->update()){
                    $data['res'] = "deactivate";
                    return response()->json($data);
                }else{
                    $data['res'] = "false";
                    return response()->json($data);
                }
            }elseif($action == 'active'){
                $doctor = User::find($id);
                $doctor->active = 1;
                if($doctor->update()){
                    $data['res'] = "active";
                    return response()->json($data);
                }else{
                    $data['res'] = "false";
                    return response()->json($data);
                }
            }else{
                $data['res'] = "false";
                return response()->json($data);
            }
        }
        $data['res'] = "false";
        return response()->json($data);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function search(Request $request){
        $param = $request->get('param');

        if(isset($param)){
            if(strcasecmp($param, "all") == 0){
                $question = Question::all();
                $answer = Answer::all();
                $failQuestion = FailQuestion::all();
                $questions = $question->merge($answer)->merge($failQuestion)->sortByDesc('date_add');
                foreach($questions as $item){
                    $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                    $hours = floor($timeDifferent/60);
                    $minutes = $timeDifferent - ($hours*60);
                    $item->date_add = 60 - $minutes;
                    $item->hours = 24-($hours+1);
                }
                $questions = array_values($questions->toArray());
                $data['res'] = "success";
                $data['questions'] = $questions;
                return response()->json($data);
            }
            if(strcasecmp($param, "open") == 0){
                $questions = Question::where('progress', '0')->orderBy('date_add', 'desc')->get();
                $data['res'] = "success";
                foreach($questions as $item){
                    $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                    $hours = floor($timeDifferent/60);
                    $minutes = $timeDifferent - ($hours*60);
                    $item->date_add = 60 - $minutes;
                    $item->hours = 24-($hours+1);
                }
                $data['questions'] = $questions;
                return response()->json($data);
            }else if(strcasecmp($param, "In Progress") == 0){
                $questions = Question::where('progress', '1')->orderBy('date_add', 'desc')->get();
                $data['res'] = "success";
                foreach($questions as $item){
                    $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                    $hours = floor($timeDifferent/60);
                    $minutes = $timeDifferent - ($hours*60);
                    $item->date_add = 60 - $minutes;
                    $item->hours = 24-($hours+1);
                }
                $data['questions'] = $questions;
                return response()->json($data);
            }else if(strcasecmp($param, "Complete") == 0){
                $questions = Answer::all();
                $data['res'] = "success";
                foreach($questions as $item){
                    $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                    $hours = floor($timeDifferent/60);
                    $minutes = $timeDifferent - ($hours*60);
                    $item->date_add = 60 - $minutes;
                    $item->hours = 24-($hours+1);
                }
                $data['questions'] = $questions;
                return response()->json($data);
            }
            else {
                $data['res'] = "false";
            }
        }else{
            $data['res'] = "false";
            return response()->json($data);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function smartSearch(Request $request){
        $param = $request->get('param');
        if($param == ''){
            $question = Question::all();
            $answer = Answer::all();
            $failQuestion = FailQuestion::all();
            $questions = $question->merge($answer)->merge($failQuestion);
            foreach($questions as $item){
                $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                $hours = floor($timeDifferent/60);
                $minutes = $timeDifferent - ($hours*60);
                $item->date_add = 60 - $minutes;
                $item->hours = 24-($hours+1);
            }
            $data['res'] = "success";
            $data['questions'] = $questions;
            return response()->json($data);
        }
        if(isset($param)){
            $question = Question::where('question', 'like', $param. '%')->orWhere('description', 'like', $param. '%')->get();
            $answer = Answer::where('question', 'like', $param. '%')->orWhere('description', 'like', $param. '%')->get();
            $failQuestion = FailQuestion::where('question', 'like', $param. '%')->orWhere('description', 'like', $param. '%')->get();
            $questions = $question->merge($answer)->merge($failQuestion);
            foreach($questions as $item) {
                $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                $hours = floor($timeDifferent / 60);
                $minutes = $timeDifferent - ($hours * 60);
                $item->date_add = 60 - $minutes;
                $item->hours = 24 - ($hours + 1);
            }
            $data['res'] = "success";
            $data['questions'] = $questions;
            return response()->json($data);
        }else{
            $data['res'] = "false";
            return response()->json($data);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function sortSearch(Request $request){
        $param = $request->get('param');
        $like = $request->get('like');
        $sort = $request->get('sort');
        if($param == "All" OR $param == "Complete" OR $param == "In Progress" OR $param == "Open"){
            if(strcasecmp($param, "all") == 0){
                if($sort == "ASC") {
                    $question = Question::all();
                    $answer = Answer::all();
                    $failQuestion = FailQuestion::all();
                    $questions = $question->merge($answer)->merge($failQuestion)->sortBy('date_add');
                }else{
                    $question = Question::all();
                    $answer = Answer::all();
                    $failQuestion = FailQuestion::all();
                    $questions = $question->merge($answer)->merge($failQuestion)->sortByDesc('date_add');
                }
                foreach($questions as $item){
                    $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                    $hours = floor($timeDifferent/60);
                    $minutes = $timeDifferent - ($hours*60);
                    $item->date_add = 60 - $minutes;
                    $item->hours = 24-($hours+1);
                }
                $questions = array_values($questions->toArray());
                $data['questions'] = $questions;
                $data['res'] = "success";
                return response()->json($data);
            }
            if(strcasecmp($param, "open") == 0){
                if($sort == "ASC") {
                    $questions = Question::where('progress', '0')->orderBy('date_add', 'desc')->get();
                }else{
                    $questions = Question::where('progress', '0')->orderBy('date_add', 'desc')->get();
                }
                $data['res'] = "success";
                foreach($questions as $item){
                    $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                    $hours = floor($timeDifferent/60);
                    $minutes = $timeDifferent - ($hours*60);
                    $item->date_add = 60 - $minutes;
                    $item->hours = 24-($hours+1);
                }
                $data['questions'] = $questions;
                $data['res'] = "success";
                return response()->json($data);
            }else if(strcasecmp($param, "In Progress") == 0){
                if($sort == "ASC") {
                    $questions = Question::where('progress', '1')->orderBy('date_add', 'asc')->get();
                }else{
                    $questions = Question::where('progress', '1')->orderBy('date_add', 'desc')->get();
                }
                foreach($questions as $item){
                    $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                    $hours = floor($timeDifferent/60);
                    $minutes = $timeDifferent - ($hours*60);
                    $item->date_add = 60 - $minutes;
                    $item->hours = 24-($hours+1);
                }
                $data['questions'] = $questions;
                $data['res'] = "success";
                return response()->json($data);
            }else if(strcasecmp($param, "Complete") == 0) {
                if($sort == "ASC") {
                    $questions = Answer::orderBy('date_add','asc')->get();
                }else{
                    $questions = Answer::orderBy('date_add','desc')->get();
                }
                foreach($questions as $item) {
                    $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                    $hours = floor($timeDifferent / 60);
                    $minutes = $timeDifferent - ($hours * 60);
                    $item->date_add = 60 - $minutes;
                    $item->hours = 24 - ($hours + 1);
                }
                $data['questions'] = $questions;
                $data['res'] = "success";
                return response()->json($data);
            }
        }else{
            if($sort == "ASC") {
                $question = Question::where('question', 'like', $like . '%')->orWhere('description', 'like', $like . '%')->orderBy('date_add', 'asc')->get();
                $answer = Answer::where('question', 'like', $like . '%')->orWhere('description', 'like', $like . '%')->orderBy('date_add', 'asc')->get();
                $failQuestion = FailQuestion::where('question', 'like', $like . '%')->orWhere('description', 'like', $like . '%')->orderBy('date_add', 'asc')->get();
            }else{
                $question = Question::where('question', 'like', $like . '%')->orWhere('description', 'like', $like . '%')->orderBy('date_add', 'desc')->get();
                $answer = Answer::where('question', 'like', $like . '%')->orWhere('description', 'like', $like . '%')->orderBy('date_add', 'desc')->get();
                $failQuestion = FailQuestion::where('question', 'like', $like . '%')->orWhere('description', 'like', $like . '%')->orderBy('date_add', 'desc')->get();
            }
            $questions = $question->merge($answer)->merge($failQuestion);
            foreach($questions as $item) {
                $timeDifferent = Carbon::now()->diffInMinutes(Carbon::parse($item->date_add));
                $hours = floor($timeDifferent / 60);
                $minutes = $timeDifferent - ($hours * 60);
                $item->date_add = 60 - $minutes;
                $item->hours = 24 - ($hours + 1);
            }
            $data['res'] = "success";
            $data['questions'] = $questions;
            return response()->json($data);
        }

    }
}
