<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="viewport" content="width=device-width">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="title" content="">
    <meta property="og:title" content="">
    <meta property="og:type" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content="">
    <meta property="og:url" content="">
    <title>Peppling</title>
    <script src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" ></script>
    <link href="{!! asset('css/main.min.css') !!}" rel="stylesheet">
</head>
<body class="site">
<header>
    <div class="container">
        <div class="header">
            <div class="header__logo"><a class="logotype" href="{!! route('main') !!}"></a></div>
            <div class="header__menu"><a class="menu_items" href="#"></a></div>
        </div>
    </div>
</header>
<main class="site_content">
    <div class="dashboard__main">
        <div class="register_table account ">
        {!! Form::open(
           [
             'url'=>route('registration'),
             'class'=>'physician__form',
             'method'=>'POST',
              'enctype'=>'multipart/form-data',
              'style'=>'position: relative'
           ])
         !!}
        <label>User name</label>
        <input type="text" name="user_name" placeholder="User name"
            @if (old('user_name'))
                value="{!! old('user_name') !!}"
            @endif
            @if ($errors->has('user_name'))
               style="border-color: #ac2925"
            @endif
        >
        @if ($errors->has('user_name'))
            <p class="errorMessage">
                <strong>{{ $errors->first('user_name') }}</strong>
            </p>
        @endif
        <label>User Email</label>
        <input type="text" name="email" placeholder="User email"
            @if (old('email'))
                value="{!! old('email') !!}"
            @endif
            @if ($errors->has('email'))
                 style="border-color: #ac2925"
            @endif
        >
        @if ($errors->has('user_email'))
            <p class="errorMessage">
                <strong>{{ $errors->first('user_email') }}</strong>
            </p>
        @endif
        <label>Password</label>
        <input type="text" name="password" placeholder="Password" id="password"
            @if (old('password'))
                value="{!! old('password') !!}"
            @endif
            @if ($errors->has('password'))
                style="border-color: #ac2925"
            @endif
        >
        @if ($errors->has('password'))
            <p class="errorMessage">
                <strong>{{ $errors->first('password') }}</strong>
            </p>
        @endif
        <label style="width: 100%">Confirm Password</label>
        <input type="text" name="password_confirmation" id="password-confirm" placeholder="Confirm Password"
            @if (old('password_confirmation'))
                value="{!! old('password_confirmation') !!}"
            @endif
            @if ($errors->has('password_confirmation'))
               style="border-color: #ac2925"
            @endif
        >
        <label>Profession</label>
        <input type="text" name="profession" placeholder="General practitioner"
            @if (old('profession'))
                value="{!! old('profession') !!}"
            @endif
            @if ($errors->has('profession'))
               style="border-color: #ac2925"
            @endif
        >
        @if ($errors->has('profession'))
            <p class="errorMessage">
                <strong>{{ $errors->first('profession') }}</strong>
            </p>
        @endif
        <label>First Name</label>
        <input type="text" name="name" placeholder="Name of physician"
            @if (old('name'))
                value="{!! old('name') !!}"
            @endif
            @if ($errors->has('name'))
               style="border-color: #ac2925"
            @endif
        >
        @if ($errors->has('name'))
            <p class="errorMessage">
                <strong>{{ $errors->first('name') }}</strong>
            </p>
        @endif
        <label>Last Name</label>
        <input type="text" name="lastName" placeholder="Last name"
            @if (old('lastName'))
                value="{!! old('lastName') !!}"
            @endif
            @if ($errors->has('lastName'))
               style="border-color: #ac2925"
            @endif
        >
        @if ($errors->has('lastName'))
            <p class="errorMessage">
                <strong>{{ $errors->first('lastName') }}</strong>
            </p>
        @endif
        <label>Country</label>
        <input type="text" name="country" placeholder="Country name"
            @if (old('country'))
                value="{!! old('country') !!}"
            @endif
            @if ($errors->has('country'))
               style="border-color: #ac2925"
            @endif
        >
        @if ($errors->has('country'))
            <p class="errorMessage">
                <strong>{{ $errors->first('country') }}</strong>
            </p>
        @endif
        <label>Paypal email</label>
        <input type="text" name="paypal_email" placeholder="Paypal email"
            @if (old('paypal_email'))
                value="{!! old('paypal_email') !!}"
            @endif
            @if ($errors->has('paypal_email'))
               style="border-color: #ac2925"
            @endif
        >
        @if ($errors->has('paypal_email'))
            <p class="errorMessage">
                <strong>{{ $errors->first('country') }}</strong>
            </p>
        @endif
        <label>Avatar</label>
        <input type="file" name="image" accept=".jpg, .jpeg, .png" placeholder="no">
        <input type="submit" value="submit" name="submit" >
        {!! Form::close() !!}
    </div>
    </div>
</main>
<footer>
    <div class="container">
        <div class="footer">
            <p class="footer__copyright">© Peppling 2018, All Rights Reserved.</p>
            <ul class="footer__menu">
                <li class="footer_items"><a class="footer_links" href="#">Privacy & Cookies</a></li>
                <li class="footer_items"><a class="footer_links" href="#">Legal</a></li>
                <li class="footer_items"><a class="footer_links" href="#">Advertise</a></li>
                <li class="footer_items"><a class="footer_links" href="#">Help</a></li>
            </ul>
        </div>
    </div>
</footer>
<script src="{!! asset('js/libs.min.js') !!}"></script>
<script src="{!! asset('js/common.js') !!}"></script>
</body>
</html>