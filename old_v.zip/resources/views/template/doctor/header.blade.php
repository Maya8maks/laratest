<input type="hidden" id="doctorId" value="{!! $doctor->id !!}">
<div class="container">
    <button class="burger"><i class="fas fa-bars"></i></button>
    <div class="header">
        <div class="header__logo"><a class="logotype" href="{!! route('main') !!}"></a></div>
        <div class="header__btn_doctor">
            <p class="menu_items">Amount:
                @if( isset($payment->receive))
                    {!! $payment->receive !!}
                @else
                    0
                @endif
            </p>
        </div>
        <div class="header__btn_doctor"><a class="menu_items" href="{!! route('logoutUser') !!}">Logout</a></div>
    </div>
</div>