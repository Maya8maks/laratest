<div class="dashboard__main">
    <div class="dashboard_table_doctor">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__title"><b>Title</b></li>
            <li class="table__time order_time"><b>Remaining time / Time completed</b></li>
            <li class="table__btn"></li>
        </ul>
        @foreach($doctor->answers as $answer)
            <ul class="table">
                <li class="table__title">
                    <p>{{ $answer->question }}</p>
                </li>
                <?$dateRemaining = Carbon\Carbon::parse( $answer->date_finish)->format('d.M.Y');
                $timeRemaining = Carbon\Carbon::parse($answer->date_finish)->format('H:m');
                $dateCompleted = Carbon\Carbon::parse($answer->date_add)->format('d.M.Y');
                $timeCompleted = Carbon\Carbon::parse($answer->date_add)->format('H:m');
                ?>

                <li class="table__time order_time"><span class="full_hours">{{$timeRemaining}}</span><span class="date">{{$dateRemaining}} / </span><span class="full_hours">{{$timeCompleted}}</span><span class="date">{{$dateCompleted}}</span></li>
                <li class="table__btn"><a  class="doctor_complete" href="#">Complete</a></li>
                <li class="table__questions">
                    <p>{{ $answer->description }}</p>
                </li>
                <li class="table__answer">
                    <p>{{ $answer->answer}}</p>
                </li>
            </ul>
        @endforeach
    </div>
</div>