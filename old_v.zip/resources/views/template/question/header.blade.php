<div class="container">
    <button class="burger"><i class="fas fa-bars"></i></button>
    <div class="header">
        <div class="header__logo"><a class="logotype" href="{!! route('main') !!}"></a></div>
        <div class="header__menu">
            @if(!Auth::user())
                <a class="menu_items" href="{!! route('loginUser') !!}">Login</a>
                <a class="menu_items" href="{!! route('registration') !!}">Registration</a>
            @else
                @if(  Auth::user()->role == 'admin' )
                    <a class="menu_items" href="{!! route('adminDashboard') !!}">Cabinet</a>
                @else
                    <a class="menu_items" href="{!! route('dashboard' , ['id' => Auth::user()->id ])  !!}">Cabinet</a>
                @endif
                <a class="menu_items" href="{!! route('logoutUser') !!}">Logout</a>
@endif
</div>
</div>
</div>