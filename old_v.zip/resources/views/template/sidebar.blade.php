<ul class="dashboard__menu_main">
    <li class="dashboard_items"><a class="dashboard_links" href="{{route('adminDashboard')}}">Dashboard<span>View customer requests</span></a></li>
    <li class="dashboard_items"><a class="dashboard_links" href="{{route('adminOrders')}}">My Orders<span>Manage your orders</span></a></li>
    <li class="dashboard_items active_line"><a class="dashboard_links" href="#">Account<span>Settings, transactions, and more</span></a></li>
</ul>