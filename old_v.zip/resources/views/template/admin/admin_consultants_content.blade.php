<div class="dashboard__main">
    <div class="dashboard_table_admin">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__consul">
                <b>ID</b>
            </li>
            <li class="table__consul" >
                <b>User Name</b>
            </li>
            <li class="table__consul">
                <b>Profession</b>
            </li>
            <li class="table__consul">
                <b>First Name</b>
            </li>
            <li class="table__consul">
                <b>Last Name</b>
            </li>
            <li class="table__consul">
                <b>Country</b>
            </li>
            <li class="table__consul" style="width: 7%">
                <b>Status</b>
            </li>
            <li class="table__consul" style="width: 19%">
                <b>Email</b>
            </li>
            <li class="table__consul" style="width: 7%">
                <b>Active</b>
            </li>
        </ul>
        @if(isset($doctors))
            @foreach($doctors as $doctor)
                <?php
                $answers = $doctor->answers()
                ?>
                <ul class="table  table_consultant">
                    <li class="table__consul">
                        <b class="customer_table_text">{!! $doctor->id !!}</b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text">{!! $doctor->user_name !!}</b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text">{!! $doctor->profession !!}</b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text">{!! $doctor->name !!}</b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text">{!! $doctor->lastname !!}</b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text">{!! $doctor->country !!}</b>
                    </li>
                    <li class="table__consul" style="width: 7%">
                        @if($doctor->status == 0)
                            <b style="color: #1c7430" class="customer_table_text">Active</b>
                        @else
                            <b style="color: #721c24" class="customer_table_text">Not Active</b>
                        @endif
                    </li>
                    <li class="table__consul" style="width: 19%">
                        <b class="customer_table_text">{!! $doctor->email !!}</b>
                    </li>
                    <li class="table__consul" style="width: 7%">
                        @if($doctor->active == 1)
                            {!! Form::open(
                               [
                                 'url'=>route('ActiveUser'),
                                 'method'=>'POST',
                                 'enctype'=>'multipart/form-data',
                               ])
                            !!}
                                <input type="hidden" name="id" value="{!! $doctor->id !!}"/>
                                <input type="hidden" name="action" value="deactivate"/>
                                <input class="deactivateUser" type="submit" value="Deactivate" name="submit" >
                            {!! Form::close() !!}
                        @else
                            {!! Form::open(
                               [
                                 'url'=>route('ActiveUser'),
                                 'method'=>'POST',
                                 'enctype'=>'multipart/form-data',
                               ])
                            !!}
                            <input type="hidden" name="id" value="{!! $doctor->id !!}"/>
                            <input type="hidden" name="action" value="active"/>
                            <input type="submit" class="activeUser" value="Active" name="submit" >
                            {!! Form::close() !!}
                        @endif
                    </li>
                </ul>
            @endforeach
        @endif
    </div>
</div>