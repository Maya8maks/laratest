<div class="dashboard__main">
    <div class="dashboard_table_admin">
        <h5 class="table_title">Customer Requests</h5>
        <p  style="width: 60px; text-align: center; display: inline-block;" >{{$payments->sum('receive')}}</p>
        {!! Form::open(
            [
            'url'=>route('massPay'),
            'class'=>'physician__form',
            'method'=>"POST",
            'style'=>'position: relative; display: inline-block;',
            ])
        !!}
            <input name="payments" type="hidden" value="{{$payments}}" readonly>
            <input type="submit" style="width: 100px" class="payBtn payBtn-a" name="submit" value="Pay Now">
        {!! Form::close() !!}
        @if ($errors->has('success'))
            <h1 style="color: green">Payment Success</h1>
        @endif
        @if ($errors->has('failed'))
            <h1 style="color: #ac2925">Payment failed</h1>
        @endif
        @if ($errors->has('bd'))
            <h1 style="color: #ac2925">{!! $errors->first('bd')!!}</h1>
        @endif
        <ul class="table head">
            <li class="table__consul__payments" style="width: 5%">
                <b>ID</b>
            </li>
            <li class="table__consul__payments">
                <b>First Name</b>
            </li>
            <li class="table__consul__payments">
                <b>Last Name</b>
            </li>
            <li class="table__consul__payments" style="width: 25%">
                <b>Amount to pay</b>
            </li>
            <li class="table__consul__payments">
                <b>All amount doctor receive</b>
            </li>
            <li class="table__consul__payments">
                <b>Paypal email</b>
            </li>
            <li class="table__consul__payments">
                <b>All amount admin receive</b>
            </li>
        </ul>
        @if(isset($doctors))
            @foreach($doctors as $doctor)
                <?php $payment = $doctor->payment?>
                <ul class="table  table_consultant">
                    <li class="table__consul__payments" style="width: 5%">
                        <b class="customer_table_text">{!! $doctor->id !!}</b>
                    </li>
                    <li class="table__consul__payments">
                        <b class="customer_table_text">{!! $doctor->name !!}</b>
                    </li>
                    <li class="table__consul__payments">
                        <b class="customer_table_text">{!! $doctor->lastname !!}</b>
                    </li>
                    @if(isset($payment->receive) and $payment->receive != '0')
                        <li class="table__consul__payments" style="width: 25%; text-align: left">
                            <b class="customer_table_text">Amount to pay : {!! $payment->receive !!}</b>
                        </li>
                    @else
                        <li class="table__consul__payments" style="width: 25%; text-align: left">
                            <b class="customer_table_text">No paypal email</b>
                            <br>
                            <b class="customer_table_text">Amount : 0</b>
                        </li>
                    @endif
                    @if(isset($payment->all_receive))
                        <li class="table__consul__payments" >
                            <b class="customer_table_text">{!! $payment->all_receive !!}</b>
                        </li>
                    @else
                        <li class="table__consul__payments">
                            <b class="customer_table_text">0</b>
                        </li>
                    @endif
                    @if(isset($payment->receive))
                        <li class="table__consul__payments">
                            <b class="customer_table_text">{!!$payment->paypal_email !!}</b>
                        </li>
                    @else
                        <li class="table__consul__payments">
                            <b class="customer_table_text"></b>
                        </li>
                    @endif
                    @if(isset($payment->receive))
                        <li class="table__consul__payments">
                            <b class="customer_table_text">{!!$payment->admin_receive !!}</b>
                        </li>
                    @else
                        <li class="table__consul__payments">
                            <b class="customer_table_text"></b>
                        </li>
                    @endif
                </ul>
            @endforeach
        @endif
    </div>
</div>