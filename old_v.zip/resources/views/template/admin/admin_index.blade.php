<div class="dashboard__main">
    <div class="dashboard_table_admin">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__time" style="width: 45%"><b>Title</b></li>
            {{--@if(isset($search))--}}
                {{--<li class="table__time"><b><a href="{!! route('orderBySearch', array('orderBy'=>$orderByDay, 'search'=>$search))!!}">Remaining time</a></b></li>--}}
            {{--@else--}}
                {{--<li class="table__time"><b><a href="{!! route('adminDashboardOrderBy', array('orderBy'=>$orderByDay))!!}">Remaining time</a></b></li>--}}
            {{--@endif--}}
            <li class="table__time"><b><a class="time__sort"   href="#">Remaining time</a></b></li>
            <li class="table__time"><b>Email address</b></li>
            <li class="table__btn" style=" width: 18%;"><b>Question</b></li>
        </ul>
        <div id="admin_dashboard">
            @if(isset($questions))
            @foreach($questions as $question)
                <ul class="table">
                    <li class="table__time" style="text-align: left; width: 45%">
                        <p>{{ $question->question }}</p>
                    </li>
                    <?  $timeDifferent = Carbon\Carbon::now()->diffInMinutes(Carbon\Carbon::parse($question->date_add));
                        $hours = floor($timeDifferent/60);
                        $minutes = $timeDifferent - ($hours*60)
                    ?>
                    <li class="table__time">
                        <span class="hours">
                            {!! 24-($hours+1) !!} hours
                        </span>
                        <span class="min">
                            {!! 60 - $minutes !!} min
                        </span>
                    </li>
                    <li  class="table__time">
                        <p>{!! $question->user_email !!}</p>
                    </li>
                    <li class="table__btn" style=" width: 18%;">
                        @if($question->status == true)
                            <a data-typeid="{!! $question->id !!}" class="complete" href="#">Complete</a>
                        @elseif($question->status == false)
                            @if($question->progress == true)
                                <a  data-typeid="{!! $question->id !!}" class="inProgressConsultant" href="#">In Progress</a>
                            @else
                                <a data-typeid="{!! $question->id !!}" class="answer" href="#">Question</a>
                            @endif
                        @endif
                    </li>
                    @if($question->status == true)
                        <li class="table__questions" >
                            <p>{{ $question->description }}</p>
                        </li>
                        <li class="table__answer">
                            <p>{{ $question->answer }}</p>
                            <p>This question in answer by {!! $question->doctorName($question->progressBy) !!}</p>
                            @if($question->fileUrl)
                                <div class="OpenFile"><a href="{!!$question->fileUrl !!}" target="_blank"><span class="inputFileSpan"><i class="fas fa-paperclip"></i></span></a></div>
                            @endif
                        </li>
                    @elseif($question->status == false)
                        @if($question->progress == true)
                            <li class="table__questions" >
                                <p>{{ $question->description }}</p>
                            </li>
                            <li class="table__answer">
                                <p>{{ $question->description }}</p>
                                @if($question->fileUrl)
                                    <div class="OpenFile"><a href="{!! $question->fileUrl !!}" target="_blank"><span class="inputFileSpan"><i class="fas fa-paperclip"></i></span></a></div>
                                @endif
                                <p>This question in progrees by {!! $question->doctorName($question->progressBy) !!}</p>
                            </li>
                        @else
                            <li class="table__questions" >
                                <p>{{ $question->description }}</p>
                            </li>
                            <li class="table__answer">
                                <p>{{ $question->description }}</p>
                                @if($question->fileUrl)
                                    <div class="OpenFile"><a href="{!! $question->fileUrl !!}" target="_blank"><span class="inputFileSpan"><i class="fas fa-paperclip"></i></span></a></div>
                                @endif
                            </li>
                        @endif
                    @endif
                </ul>
            @endforeach
        @endif
        </div>
    </div>
</div>