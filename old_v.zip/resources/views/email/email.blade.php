<h3>Hello our specialist Doctor {!! $data['doctor_name'] !!} {!! $data['doctor_lastName'] !!}.</h3>
<h4>Your question : {!! $data['question'] !!}</h4>
<h4>Answer:
    {!! $data['answer']!!}
</h4>