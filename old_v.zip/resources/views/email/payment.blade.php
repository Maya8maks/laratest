<h3>Hello you get Payment from Peppling.</h3>
<h4>Amount is : {!! $data['amount'] !!}</h4>
