<h3>Hello.</h3>
<h3>New doctor register {!! $data['doctor_name'] !!} {!! $data['doctor_lastName'] !!}</h3>
<h4>Confirm his status</h4>