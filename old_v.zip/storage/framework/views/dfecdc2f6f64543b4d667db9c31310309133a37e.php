<div class="dashboard__main">
    <div class="dashboard_table">
        <h5 class="table_title">Customer Requests</h5>
        <?php if($errors->has('success')): ?>
            <h1 style="color: green"><?php echo $errors->first('success'); ?></h1>
        <?php endif; ?>
        <?php if($errors->has('bd')): ?>
            <h1 style="color: #ac2925"><?php echo $errors->first('bd'); ?></h1>
        <?php endif; ?>
        <ul class="table head">
            <li class="table__consul__payments" style="width: 5%">
                <b>ID</b>
            </li>
            <li class="table__consul__payments">
                <b>First Name</b>
            </li>
            <li class="table__consul__payments">
                <b>Last Name</b>
            </li>
            <li class="table__consul__payments" style="width: 25%">
                <b>Amount to pay</b>
            </li>
            <li class="table__consul__payments">
                <b>All amount doctor receive</b>
            </li>
            <li class="table__consul__payments">
                <b>Paypal email</b>
            </li>
            <li class="table__consul__payments">
                <b>All amount admin receive</b>
            </li>
        </ul>
        <?php if(isset($doctors)): ?>
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $payment = $doctor->payment?>
                <ul class="table  table_consultant">
                    <li class="table__consul__payments" style="width: 5%">
                        <b class="customer_table_text"><?php echo $doctor->id; ?></b>
                    </li>
                    <li class="table__consul__payments">
                        <b class="customer_table_text"><?php echo $doctor->name; ?></b>
                    </li>
                    <li class="table__consul__payments">
                        <b class="customer_table_text"><?php echo $doctor->lastname; ?></b>
                    </li>
                    <?php if(isset($payment->receive) and $payment->receive != '0'): ?>
                        <li class="table__consul__payments" style="width: 25%; text-align: left">
                            <?php echo Form::open(
                                    [
                                    'url'=>route('clearDoctorPayment'),
                                    'class'=>'physician__form',
                                    'method'=>"POST",
                                    'style'=>'position: relative',
                                    ]); ?>

                            <input type="hidden" name="doctorId" value="<?php echo $payment->user_id; ?>">
                            <input name="amount"  style="width: 60px; text-align: center" value="<?php echo $payment->receive; ?>">
                            <input type="submit" style="width: 100px" class="payBtn payBtn-a" name="submit" value="Pay Now">
                            <?php echo Form::close(); ?>

                        </li>
                        
                            
                                
                                
                                
                                
                                
                                
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        </li>
                    <?php else: ?>
                        <li class="table__consul__payments" style="width: 25%; text-align: left">
                            <b class="customer_table_text">No paypal email</b>
                            <br>
                            <b class="customer_table_text">Amount : 0</b>
                        </li>
                    <?php endif; ?>
                    <?php if(isset($payment->all_receive)): ?>
                        <li class="table__consul__payments" >
                            <b class="customer_table_text"><?php echo $payment->all_receive; ?></b>
                        </li>
                    <?php else: ?>
                        <li class="table__consul__payments">
                            <b class="customer_table_text">0</b>
                        </li>
                    <?php endif; ?>
                    <?php if(isset($payment->receive)): ?>
                        <li class="table__consul__payments">
                            <b class="customer_table_text"><?php echo $payment->paypal_email; ?></b>
                        </li>
                    <?php else: ?>
                        <li class="table__consul__payments">
                            <b class="customer_table_text"></b>
                        </li>
                    <?php endif; ?>
                    <?php if(isset($payment->receive)): ?>
                        <li class="table__consul__payments">
                            <b class="customer_table_text"><?php echo $payment->admin_receive; ?></b>
                        </li>
                    <?php else: ?>
                        <li class="table__consul__payments">
                            <b class="customer_table_text"></b>
                        </li>
                    <?php endif; ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>