<div class="container">
    <button class="burger"><i class="fas fa-bars"></i></button>
    <div class="header">
        <div class="header__logo"><a class="logotype" href="<?php echo route('main'); ?>"></a></div>
        <div class="header__menu">
            <?php if(!Auth::user()): ?>
                <a class="menu_items" href="<?php echo route('loginUser'); ?>">Login</a>
                <a class="menu_items" href="<?php echo route('registration'); ?>">Registration</a>
            <?php else: ?>
                <?php if(  Auth::user()->role == 'admin' ): ?>
                    <a class="menu_items" href="<?php echo route('adminDashboard'); ?>">Cabinet</a>
                <?php else: ?>
                    <a class="menu_items" href="<?php echo route('dashboard' , ['id' => Auth::user()->id ]); ?>">Cabinet</a>
                <?php endif; ?>
                <a class="menu_items" href="<?php echo route('logoutUser'); ?>">Logout</a>
<?php endif; ?>
</div>
</div>
</div>