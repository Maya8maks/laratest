<div class="dashboard__main">
    <div class="dashboard_table">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__time" style="width: 45%"><b>Title</b></li>
            
                
            
                
            
            <li class="table__time"><b><a class="time__sort"   href="#">Remaining time</a></b></li>
            <li class="table__time"><b>Email address</b></li>
            <li class="table__btn" style=" width: 18%;"><b>Question</b></li>
        </ul>
        <div id="admin_dashboard">
            <?php if(isset($questions)): ?>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="table">
                    <li class="table__time" style="text-align: left; width: 45%">
                        <p><?php echo e($question->question); ?></p>
                    </li>
                    <?  $timeDifferent = Carbon\Carbon::now()->diffInMinutes(Carbon\Carbon::parse($question->date_add));
                        $hours = floor($timeDifferent/60);
                        $minutes = $timeDifferent - ($hours*60)
                    ?>
                    <li class="table__time">
                        <span class="hours">
                            <?php echo 24-($hours+1); ?> hours
                        </span>
                        <span class="min">
                            <?php echo 60 - $minutes; ?> min
                        </span>
                    </li>
                    <li  class="table__time">
                        <p><?php echo $question->user_email; ?></p>
                    </li>
                    <li class="table__btn" style=" width: 18%;">
                        <?php if($question->status == true): ?>
                            <a class="complete" href="#">Complete</a>
                        <?php elseif($question->status == false): ?>
                            <?php if($question->progress == true): ?>
                                <a class="inProgressConsultant" href="#">In Progress</a>
                            <?php else: ?>
                                <a class="answer" href="#">Question</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </li>
                    <?php if($question->status == true): ?>
                        <li class="table__questions" >
                            <p><?php echo e($question->description); ?></p>
                        </li>
                        <li class="table__answer">
                            <p><?php echo e($question->answer); ?></p>
                            <p>This question in answer by <?php echo $question->doctorName($question->progressBy); ?></p>
                            <?php if($question->fileUrl): ?>
                                <div class="OpenFile"><a href="<?php echo asset('storage/upload/'.$question->fileUrl); ?>" target="_blank"><span class="inputFileSpan"><i class="fas fa-paperclip"></i></span></a></div>
                            <?php endif; ?>
                        </li>
                    <?php elseif($question->status == false): ?>
                        <?php if($question->progress == true): ?>
                            <li class="table__questions" >
                                <p><?php echo e($question->description); ?></p>
                            </li>
                            <li class="table__answer">
                                <p><?php echo e($question->description); ?></p>
                                <?php if($question->fileUrl): ?>
                                    <div class="OpenFile"><a href="<?php echo asset('storage/upload/'.$question->fileUrl); ?>" target="_blank"><span class="inputFileSpan"><i class="fas fa-paperclip"></i></span></a></div>
                                <?php endif; ?>
                                <p>This question in progrees by <?php echo $question->doctorName($question->progressBy); ?></p>
                            </li>
                        <?php else: ?>
                            <li class="table__questions" >
                                <p><?php echo e($question->description); ?></p>
                            </li>
                            <li class="table__answer">
                                <p><?php echo e($question->description); ?></p>
                                <?php if($question->fileUrl): ?>
                                    <div class="OpenFile"><a href="<?php echo asset('storage/upload/'.$question->fileUrl); ?>" target="_blank"><span class="inputFileSpan"><i class="fas fa-paperclip"></i></span></a></div>
                                <?php endif; ?>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </div>
    </div>
</div>