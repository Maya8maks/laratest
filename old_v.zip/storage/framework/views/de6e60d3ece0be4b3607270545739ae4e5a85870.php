<div class="dashboard__main">
    <div class="dashboard_table">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__consul">
                <b>ID</b>
            </li>
            <li class="table__consul" >
                <b>User Name</b>
            </li>
            <li class="table__consul">
                <b>Profession</b>
            </li>
            <li class="table__consul">
                <b>First Name</b>
            </li>
            <li class="table__consul">
                <b>Last Name</b>
            </li>
            <li class="table__consul">
                <b>Country</b>
            </li>
            <li class="table__consul" style="width: 7%">
                <b>Status</b>
            </li>
            <li class="table__consul" style="width: 19%">
                <b>Email</b>
            </li>
            <li class="table__consul" style="width: 7%">
                <b>Active</b>
            </li>
        </ul>
        <?php if(isset($doctors)): ?>
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $answers = $doctor->answers()
                ?>
                <ul class="table  table_consultant">
                    <li class="table__consul">
                        <b class="customer_table_text"><?php echo $doctor->id; ?></b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text"><?php echo $doctor->user_name; ?></b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text"><?php echo $doctor->profession; ?></b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text"><?php echo $doctor->name; ?></b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text"><?php echo $doctor->lastname; ?></b>
                    </li>
                    <li class="table__consul">
                        <b class="customer_table_text"><?php echo $doctor->country; ?></b>
                    </li>
                    <li class="table__consul" style="width: 7%">
                        <?php if($doctor->status == 0): ?>
                            <b style="color: #1c7430" class="customer_table_text">Active</b>
                        <?php else: ?>
                            <b style="color: #721c24" class="customer_table_text">Not Active</b>
                        <?php endif; ?>
                    </li>
                    <li class="table__consul" style="width: 19%">
                        <b class="customer_table_text"><?php echo $doctor->email; ?></b>
                    </li>
                    <li class="table__consul" style="width: 7%">
                        <?php if($doctor->active == 1): ?>
                            <?php echo Form::open(
                               [
                                 'url'=>route('ActiveUser'),
                                 'method'=>'POST',
                                 'enctype'=>'multipart/form-data',
                               ]); ?>

                                <input type="hidden" name="id" value="<?php echo $doctor->id; ?>"/>
                                <input type="hidden" name="action" value="deactivate"/>
                                <input class="deactivateUser" type="submit" value="Deactivate" name="submit" >
                            <?php echo Form::close(); ?>

                        <?php else: ?>
                            <?php echo Form::open(
                               [
                                 'url'=>route('ActiveUser'),
                                 'method'=>'POST',
                                 'enctype'=>'multipart/form-data',
                               ]); ?>

                            <input type="hidden" name="id" value="<?php echo $doctor->id; ?>"/>
                            <input type="hidden" name="action" value="active"/>
                            <input type="submit" class="activeUser" value="Active" name="submit" >
                            <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>