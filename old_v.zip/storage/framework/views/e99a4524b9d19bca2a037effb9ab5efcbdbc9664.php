<div class="dashboard__main">
    <div class="dashboard_table">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__title table__title__main" style="width: 25%"><b><a href="<?php echo route('adminOrders'); ?>">Title</a></b></li>
            <li class="table__title table__title__main" style="width: 25%"><b><a href="<?php echo route('adminOrderOrderBy', array('orderBy'=>'name')); ?>">Name</a></b></li>
            <li class="table__time"><b><a href="<?php echo route('adminOrderOrderBy', array('orderBy'=>'date_finish')); ?>">Finnish time</a></b></li>
            <li class="table__btn"></li>
        </ul>
        <?php if(isset($doctors)): ?>
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="table head">
                    <li class="table__title" style="text-align: center"><b>Doctor name : <?php echo $doctor->name; ?></b></li>
                </ul>
                <?php $__currentLoopData = $doctor->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <ul class="table">
                            <li class="table__title">
                                <p><?php echo e($answer->question); ?></p>
                            </li>
                            <?$date = Carbon\Carbon::parse($answer->date_finish)->format('d.M.Y');
                            $time = Carbon\Carbon::parse($answer->date_finish)->format('H:m')?>

                            <li class="table__time"><span class="full_hours"><?php echo e($time); ?></span><span class="date"><?php echo e($date); ?></span></li>
                            <li class="table__btn"><a class="complete" href="#">Complete</a></li>
                            <li class="table__questions">
                                <p><?php echo e($answer->description); ?></p>
                            </li>
                            <li class="table__answer">
                                <p><?php echo e($answer->answer); ?></p>
                            </li>
                        </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(isset($answers)): ?>
            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="table head">
                        <li class="table__title" style="text-align: center"><b>Doctor name : <?php echo $answer->doctorName($answer->user_id); ?></b></li>
                    </ul>
                    <ul class="table">
                        <li class="table__title">
                            <p><?php echo e($answer->question); ?></p>
                        </li>
                        <?$date = Carbon\Carbon::parse($answer->date_finish)->format('d.M.Y');
                        $time = Carbon\Carbon::parse($answer->date_finish)->format('H:m')?>

                        <li class="table__time"><span class="full_hours"><?php echo e($time); ?></span><span class="date"><?php echo e($date); ?></span></li>
                        <li class="table__btn"><a class="complete" href="#">Complete</a></li>
                        <li class="table__questions">
                            <p><?php echo e($answer->description); ?></p>
                        </li>
                        <li class="table__answer">
                            <p><?php echo e($answer->answer); ?></p>
                        </li>
                    </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>