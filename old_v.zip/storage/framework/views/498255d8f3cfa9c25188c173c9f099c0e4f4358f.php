<ul class="dashboard__menu">
    <li class="dashboard_items" data-sidebar="1"><a class="dashboard_links" href="<?php echo e(route('adminDashboard')); ?>">Dashboard<span>View customer requests</span></a></li>
    <li class="dashboard_items" data-sidebar="2"><a class="dashboard_links" href="<?php echo e(route('adminConsultants')); ?>">Consultants<span>Manage doctor orders</span></a></li>
    <li class="dashboard_items" data-sidebar="3"><a class="dashboard_links" href="<?php echo e(route('adminCreateAccount')); ?>">Create Account<span>Settings, transactions, and more</span></a></li>
</ul>