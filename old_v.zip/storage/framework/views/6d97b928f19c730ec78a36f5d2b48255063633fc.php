<div class="footer">
    <p class="footer__copyright">© Peppling 2018, All Rights Reserved.</p>
    <ul class="footer__menu">
        <li class="footer_items"><a class="footer_links" href="#">Privacy & Cookies</a></li>
        <li class="footer_items"><a class="footer_links" href="#">Legal</a></li>
        <li class="footer_items"><a class="footer_links" href="#">Advertise</a></li>
        <li class="footer_items"><a class="footer_links" href="#">Help</a></li>
    </ul>
</div>
<script src="<?php echo asset('js/windowListener.js'); ?>"></script>