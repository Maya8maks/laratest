<div class="dashboard__main">
    <div class="dashboard_table account">
        <?php echo Form::open(
            [
                'url'=>route('register'),
                'class'=>'physician__form',
                'method'=>'POST',
                'enctype'=>'multipart/form-data',
                'style'=>'position: relative'
            ]); ?>

        <label>User name</label>
        <input type="text" name="user_name" placeholder="User name">
        <?php if($errors->has('user_name')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('user_name')); ?></strong>
            </p>
        <?php endif; ?>
        <label>User Email</label>
        <input type="text" name="user_email" placeholder="User email">
        <?php if($errors->has('user_email')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('user_email')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Password</label>
        <input type="text" name="password" placeholder="password" id="password" >
        <?php if($errors->has('password')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Confirm Password</label>
        <input type="text" name="password_confirmation" placeholder="Confirm Password" id="password-confirm">
        <label>Profession</label>
        <input type="text" name="profession" placeholder="General practitioner">
        <?php if($errors->has('profession')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('profession')); ?></strong>
            </p>
        <?php endif; ?>
        <label>First Name</label>
        <input type="text" name="name" placeholder="Name of physician">
        <?php if($errors->has('name')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Last Name</label>
        <input type="text" name="lastName" placeholder="Last name">
        <?php if($errors->has('lastName')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('lastName')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Country</label>
        <input type="text" name="country" placeholder="Country name">
        <?php if($errors->has('country')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('country')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Paypal email</label>
        <input type="text" name="paypal_email" placeholder="Paypal email">
        <?php if($errors->has('paypal_email')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('country')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Avatar</label>
        <input type="file" name="image" accept=".jpg, .jpeg, .png" placeholder="no">
        <input type="submit" value="submit" name="submit" >
        <?php echo Form::close(); ?>

    </div>
</div>