<div class="dashboard__main">
    <h1 class="physician__head">Ask a Doctor</h1><span class="physician__subtext">Answer within 24 hours</span>
    <div class="dashboard_table">
         <?php echo Form::open(
            [
                'url'=>route('main'),
                'class'=>'physician__form',
                'method'=>'POST',
                'enctype'=>'multipart/form-data',
                 'style'=>'position: relative'
            ]); ?>

            <label data-form_question_label = '1'>Your Question<span class="counter">0/120</span></label>
            <input data-form_question_input = '1' type="text" name="question"  placeholder="I have had fever every third week for last 5 months" maxlength="120">
            <label data-form_question_label = '2'>Description<span class="counterLow">0/500</span></label>
            <textarea id="counterLow" data-form_question_input = '2' name="description" placeholder="I am a 23 year old female. I have had fever every third week for last 5 months..." maxlength="500"></textarea>
            <label data-form_question_label = '3'>Email</label>
            <input data-form_question_input = '3' type="email" name="email" placeholder="eve.higgins@gmail.com">
            <input type="submit" value="submit" name="submit" id="questionSubmit">
        <?php echo Form::close(); ?>

    </div>
</div>