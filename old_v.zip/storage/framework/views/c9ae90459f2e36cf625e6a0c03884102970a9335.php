<div class="dashboard__button_menu">
        <ul class="table">
            <li  class="table__btn" style="width: 100%; padding-top:  10px; padding-left: 10px">
                <div class="physician__form">
                    <div class="inputWithIcon">
                        <input class="smartSearch" type="text" name="search_Text" placeholder="Search Text"><i class="fas fa-search"></i>
                    </div>
                </div>
            </li>
            <li  class="table__btn" style="width: 100%; padding-top:  40px; padding-left: 10px" >
                <a class="btn_answer all_search" href="#">All</a>
            </li>
            <li class="table__btn" style="width: 100%; padding-top:  10px; padding-left: 10px">
                <a class="btn_answer all_search" href="#">Open</a>
            </li>
            <li class="table__btn" style="width: 100%; padding-top: 10px; padding-left: 10px">
                <a class="btn_answer all_search" href="#">
                    In Progress
                </a>
            </li>
            <li class="table__btn" style="width: 100%; padding-top:  10px; padding-left: 10px">
                <a class="btn_answer all_search" href="#">
                    Complete
                </a>
            </li>
        </ul>
</div>
<ul class="dashboard__menu">
    <li class="dashboard_items" data-sidebar="1"><a class="dashboard_links" href="<?php echo e(route('adminDashboard')); ?>">Dashboard<span>View customer requests</span></a></li>
    <li class="dashboard_items" data-sidebar="2"><a class="dashboard_links" href="<?php echo e(route('adminConsultants')); ?>">Consultants<span>Manage doctor orders</span></a></li>
    <li class="dashboard_items" data-sidebar="3"><a class="dashboard_links" href="<?php echo e(route('adminCreateAccount')); ?>">Create Account<span>Settings, transactions, and more</span></a></li>
    <li class="dashboard_items" data-sidebar="4"><a class="dashboard_links" href="<?php echo e(route('doctorPayments')); ?>">Payment<span>Manage doctors payments</span></a></li>
</ul>

