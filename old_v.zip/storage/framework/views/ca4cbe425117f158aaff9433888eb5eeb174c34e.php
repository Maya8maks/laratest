<input type="hidden" id="doctorId" value="<?php echo $doctor->id; ?>">
<div class="container">
    <button class="burger"><i class="fas fa-bars"></i></button>
    <div class="header">
        <div class="header__logo"><a class="logotype" href="<?php echo route('main'); ?>"></a></div>
        <div class="header__btn_doctor">
            <p class="menu_items">Amount:
                <?php if( isset($payment->receive)): ?>
                    <?php echo $payment->receive; ?>

                <?php else: ?>
                    0
                <?php endif; ?>
            </p>
        </div>
        <div class="header__btn_doctor"><a class="menu_items" href="<?php echo route('logoutUser'); ?>">Logout</a></div>
    </div>
</div>