<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="viewport" content="width=device-width">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="title" content="">
    <meta property="og:title" content="">
    <meta property="og:type" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content="">
    <meta property="og:url" content="">
    <title>Peppling</title>
    <script src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" ></script>
    <link href="<?php echo asset('css/main.min.css'); ?>" rel="stylesheet">
</head>
<body class="site">
<header>
    <div class="container">
        <div class="header">
            <div class="header__logo"><a class="logotype" href="<?php echo route('main'); ?>"></a></div>
            <div class="header__menu"><a class="menu_items" href="#"></a></div>
        </div>
    </div>
</header>
<main class="site_content">
    <div class="dashboard__main">
        <div class="register_table account ">
        <?php echo Form::open(
           [
             'url'=>route('registration'),
             'class'=>'physician__form',
             'method'=>'POST',
              'enctype'=>'multipart/form-data',
              'style'=>'position: relative'
           ]); ?>

        <label>User name</label>
        <input type="text" name="user_name" placeholder="User name"
            <?php if(old('user_name')): ?>
                value="<?php echo old('user_name'); ?>"
            <?php endif; ?>
            <?php if($errors->has('user_name')): ?>
               style="border-color: #ac2925"
            <?php endif; ?>
        >
        <?php if($errors->has('user_name')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('user_name')); ?></strong>
            </p>
        <?php endif; ?>
        <label>User Email</label>
        <input type="text" name="email" placeholder="User email"
            <?php if(old('email')): ?>
                value="<?php echo old('email'); ?>"
            <?php endif; ?>
            <?php if($errors->has('email')): ?>
                 style="border-color: #ac2925"
            <?php endif; ?>
        >
        <?php if($errors->has('user_email')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('user_email')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Password</label>
        <input type="text" name="password" placeholder="Password" id="password"
            <?php if(old('password')): ?>
                value="<?php echo old('password'); ?>"
            <?php endif; ?>
            <?php if($errors->has('password')): ?>
                style="border-color: #ac2925"
            <?php endif; ?>
        >
        <?php if($errors->has('password')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </p>
        <?php endif; ?>
        <label style="width: 100%">Confirm Password</label>
        <input type="text" name="password_confirmation" id="password-confirm" placeholder="Confirm Password"
            <?php if(old('password_confirmation')): ?>
                value="<?php echo old('password_confirmation'); ?>"
            <?php endif; ?>
            <?php if($errors->has('password_confirmation')): ?>
               style="border-color: #ac2925"
            <?php endif; ?>
        >
        <label>Profession</label>
        <input type="text" name="profession" placeholder="General practitioner"
            <?php if(old('profession')): ?>
                value="<?php echo old('profession'); ?>"
            <?php endif; ?>
            <?php if($errors->has('profession')): ?>
               style="border-color: #ac2925"
            <?php endif; ?>
        >
        <?php if($errors->has('profession')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('profession')); ?></strong>
            </p>
        <?php endif; ?>
        <label>First Name</label>
        <input type="text" name="name" placeholder="Name of physician"
            <?php if(old('name')): ?>
                value="<?php echo old('name'); ?>"
            <?php endif; ?>
            <?php if($errors->has('name')): ?>
               style="border-color: #ac2925"
            <?php endif; ?>
        >
        <?php if($errors->has('name')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Last Name</label>
        <input type="text" name="lastName" placeholder="Last name"
            <?php if(old('lastName')): ?>
                value="<?php echo old('lastName'); ?>"
            <?php endif; ?>
            <?php if($errors->has('lastName')): ?>
               style="border-color: #ac2925"
            <?php endif; ?>
        >
        <?php if($errors->has('lastName')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('lastName')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Country</label>
        <input type="text" name="country" placeholder="Country name"
            <?php if(old('country')): ?>
                value="<?php echo old('country'); ?>"
            <?php endif; ?>
            <?php if($errors->has('country')): ?>
               style="border-color: #ac2925"
            <?php endif; ?>
        >
        <?php if($errors->has('country')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('country')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Paypal email</label>
        <input type="text" name="paypal_email" placeholder="Paypal email"
            <?php if(old('paypal_email')): ?>
                value="<?php echo old('paypal_email'); ?>"
            <?php endif; ?>
            <?php if($errors->has('paypal_email')): ?>
               style="border-color: #ac2925"
            <?php endif; ?>
        >
        <?php if($errors->has('paypal_email')): ?>
            <p class="errorMessage">
                <strong><?php echo e($errors->first('country')); ?></strong>
            </p>
        <?php endif; ?>
        <label>Avatar</label>
        <input type="file" name="image" accept=".jpg, .jpeg, .png" placeholder="no">
        <input type="submit" value="submit" name="submit" >
        <?php echo Form::close(); ?>

    </div>
    </div>
</main>
<footer>
    <div class="container">
        <div class="footer">
            <p class="footer__copyright">© Peppling 2018, All Rights Reserved.</p>
            <ul class="footer__menu">
                <li class="footer_items"><a class="footer_links" href="#">Privacy & Cookies</a></li>
                <li class="footer_items"><a class="footer_links" href="#">Legal</a></li>
                <li class="footer_items"><a class="footer_links" href="#">Advertise</a></li>
                <li class="footer_items"><a class="footer_links" href="#">Help</a></li>
            </ul>
        </div>
    </div>
</footer>
<script src="<?php echo asset('js/libs.min.js'); ?>"></script>
<script src="<?php echo asset('js/common.js'); ?>"></script>
</body>
</html>