<div class="dashboard__main">
    <?php echo Form::open(
        [
            'url'=>route('account',array('id'=>$doctor->id)),
            'method'=>'POST',
            'class'=>'dashboard_table account',
            'enctype'=>'multipart/form-data',
        ]); ?>

        <h5 class="table_title">My info</h5>
            <label>Username</label>
            <input type="text" readonly name="userName" value="<?php echo e($doctor->user_name); ?>">
            <?php if($errors->has('userName')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('userName')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Profession</label>
            <input type="text" readonly name="profession"  value="<?php echo e($doctor->profession); ?>">
            <?php if($errors->has('profession')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('profession')); ?></strong>
                </p>
            <?php endif; ?>
            <label>First Name</label>
            <input type="text" readonly name="name" value="<?php echo e($doctor->name); ?>">
            <?php if($errors->has('name')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Last Name</label>
            <input type="text" readonly name="lastName" value="<?php echo e($doctor->lastname); ?>">
            <?php if($errors->has('lastName')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('lastName')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Country</label>
            <input type="text"  readonly name="country" value="<?php echo e($doctor->country); ?>">
            <?php if($errors->has('country')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('country')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Authorization ID</label>
            <input disabled  name="id" value="<?php echo e($doctor->id); ?>">
            <button class="sbmt" type="submit" name="submit">Submit</button>
    <?php echo Form::close(); ?>

</div>