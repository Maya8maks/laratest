<div class="container">
    <div class="header">
        <div class="header__logo"><a class="logotype" href="<?php echo route('main'); ?>"></a></div>
        <a class="menu_items" href="<?php echo route('logoutUser'); ?>">Logout</a></div>
    </div>
</div>