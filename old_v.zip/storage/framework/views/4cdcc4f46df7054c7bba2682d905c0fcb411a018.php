<div class="dashboard__main">
    <h1 class="physician__head">Ask a Doctor</h1><span class="physician__subtext">Answer within 24 hours</span>
    <div class="dashboard_table">
        <?php echo Form::open(
        [
        'url'=>route('main'),
        'class'=>'physician__form',
        'method'=>'POST',
        'enctype'=>'multipart/form-data',
        'style'=>'position: relative',
        'id'=>'form'
        ]); ?>

        <label data-form_question_label = '1'>Your Question<span class="counter">0/120</span></label>
        <?php if(isset($question)): ?>
            <input data-form_question_input = '1' type="text" name="question"  value="<?php echo $question; ?>" maxlength="120">
        <?php else: ?>
            <input data-form_question_input = '1' type="text" name="question"  placeholder="I have had fever every third week for last 5 months" maxlength="120">
        <?php endif; ?>
        <label data-form_question_label = '2'>Description<span class="counterLow">0/500</span></label>
        <?php if(isset($description)): ?>
            <textarea id="counterLow" data-form_question_input = '2' name="description" placeholder="<?php echo $description; ?>" maxlength="500"></textarea>
        <?php else: ?>
            <textarea id="counterLow" data-form_question_input = '2' name="description" placeholder="I am a 23 year old female. I have had fever every third week for last 5 months..." maxlength="500"></textarea>
        <?php endif; ?>
        <label data-form_question_label = '3'>Email</label>
        <?php if(isset($email)): ?>
            <input data-form_question_input = '3' type="email" name="email" value="<?php echo $email; ?>">
        <?php else: ?>
            <input data-form_question_input = '3' type="email" name="email" placeholder="eve.higgins@gmail.com">
        <?php endif; ?>
        <input  value=submit name="submit" type="submit" id="QSubmit">
        <?php echo Form::close(); ?>

    </div>
</div>
