<div class="dashboard__main">
    <div class="dashboard_table_doctor">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__title"><b>Title</b></li>
            <li class="table__time"><b>Remaining time</b></li>
            <li class="table__btn"></li>
        </ul>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($question->progress == false OR ($question->progress == true AND $question->progressBy == $doctor->id )): ?>
                    <ul class="table">
                        <li class="table__title">
                            <p><?php echo e($question->question); ?></p>
                        </li>
                        <?  $timeDifferent = Carbon\Carbon::now()->diffInMinutes(Carbon\Carbon::parse($question->date_add));
                            $hours = floor($timeDifferent/60);
                            $minutes = $timeDifferent - ($hours*60) ?>
                        <li class="table__time"><span class="hours"><?php echo 24-($hours+1); ?> hours</span><span class="min"><?php echo 60 - $minutes; ?> min</span></li>

                        <li class="table__btn"><a data-typeid="<?php echo $question->id; ?>" class="fade_btn btn_answer" href="#">Answer</a></li>
                        <li class="table__text">
                            <p><?php echo e($question->description); ?></p>
                            <?php if($question->fileUrl): ?>
                                <div class="OpenFile"><a href="../<?php echo $question->fileUrl; ?>" target="_blank"><span class="inputFileSpan"><i class="fas fa-paperclip"></i></span></a></div>
                            <?php endif; ?>
                        </li>
                        <li class="table__form">
                            <?php echo Form::open(
                                [
                                    'url'=>route('answer',array('doctor_id'=>$doctor->id,'question_id'=>$question->id)),
                                    'class'=>'dashboard_form',
                                    'method'=>'POST',
                                    'enctype'=>'multipart/form-data',
                                    'style'=>'position: relative',
                                ]); ?>

                                <textarea name="text"></textarea>
                                <input type="submit"  value="submit">
                            <?php echo Form::close(); ?>

                        </li>
                        <li class="popup_submit">
                            <h2>Request complete</h2>
                            <p>Your answer is submitted!</p>
                        </li>
                    </ul>
                <?php elseif($question->progress == true): ?>
                    <ul class="table">
                        <li class="table__title">
                            <p><?php echo e($question->question); ?></p>
                        </li>
                        <?  $timeDifferent = Carbon\Carbon::now()->diffInMinutes(Carbon\Carbon::parse($question->date_add));
                        $hours = floor($timeDifferent/60);
                        $minutes = $timeDifferent - ($hours*60) ?>
                        <li class="table__time"><span class="hours"><?php echo 24-($hours+1); ?> hours</span><span class="min"><?php echo 60 - $minutes; ?> min</span></li>

                        <li class="table__btn"><a data-typeid="<?php echo $question->id; ?>" class="fade_btn inProgress" href="#">In Progress</a></li>
                        <li class="table__text">
                            <p><?php echo e($question->description); ?></p>
                            <?php if($question->fileUrl): ?>
                                <div class="OpenFile"><a href="../<?php echo $question->fileUrl; ?>" target="_blank"><span class="inputFileSpan"><i class="fas fa-paperclip"></i></span></a></div>
                            <?php endif; ?>
                        </li>
                        <li class="table__form">
                            <?php echo Form::open(
                                [
                                    'url'=>'',
                                    'class'=>'dashboard_form',
                                    'method'=>'POST',
                                    'enctype'=>'multipart/form-data',
                                    'style'=>'position: relative'
                                ]); ?>

                            <textarea readonly class="backgroundInProgress" name="text"></textarea>
                            <p>This question in progrees by <?php echo $question->doctorName($question->progressBy); ?></p>
                            <?php echo Form::close(); ?>

                        </li>
                        <li class="popup_submit">
                            <h2>Request complete</h2>
                            <p>Your answer is submitted!</p>
                        </li>
                    </ul>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>