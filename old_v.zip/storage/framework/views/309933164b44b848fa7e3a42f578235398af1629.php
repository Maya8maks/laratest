<div class="dashboard__main">
    <div class="dashboard_table">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__consul" >
                <b>User Name</b>
            </li>
            <li class="table__consul">
                <b>Profession</b>
            </li>
            <li class="table__consul">
                <b>First Name</b>
            </li>
            <li class="table__consul">
                <b>Last Name</b>
            </li>
            <li class="table__consul">
                <b>Country</b>
            </li>
            <li class="table__consul">
                <b>Authorization ID</b>
            </li>
            <li class="table__consul">
                <b>Status</b>
            </li>
            <li class="table__consul">
                <b>Member since</b>
            </li>
            <li class="table__consul">
                <b>Last activity</b>
            </li>
            <li class="table__consul">
                <b>Requests answered</b>
            </li>
            <li class="table__consul">
                <b>Revenue</b>
            </li>
            <li class="table__consul">
                <b>Email</b>
            </li>
        </ul>
        <?php if(isset($doctors)): ?>
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $answers = $doctor->answers()
                ?>
                <ul class="table">
                    <li class="table__consul">
                        <b><?php echo $doctor->user_name; ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $doctor->profession; ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $doctor->name; ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $doctor->lastname; ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $doctor->country; ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $doctor->id; ?></b>
                    </li>
                    <li class="table__consul">
                        <?php if($doctor->status == 0): ?>
                            <b style="color: #1c7430">Active</b>
                        <?php else: ?>
                            <b style="color: #721c24">Not Active</b>
                        <?php endif; ?>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $doctor->created_at; ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $doctor->last_visit; ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $answers->count(); ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $answers->count()*10; ?></b>
                    </li>
                    <li class="table__consul">
                        <b><?php echo $doctor->email; ?></b>
                    </li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>