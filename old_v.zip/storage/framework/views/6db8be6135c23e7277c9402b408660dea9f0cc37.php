<h3>Hello you get new question.</h3>
<h4>Question is : <?php echo $data['question']; ?></h4>