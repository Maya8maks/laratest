<h3>Hello our specialist Doctor <?php echo $data['doctor_name']; ?> <?php echo $data['doctor_lastName']; ?>.</h3>
<h4>Your question : <?php echo $data['question']; ?></h4>
<h4>Answer:
    <?php echo $data['answer']; ?>

</h4>