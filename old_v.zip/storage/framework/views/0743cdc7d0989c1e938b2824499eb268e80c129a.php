<div class="dashboard__main">
    <h1 class="physician__head">Ask a Doctor</h1><span class="physician__subtext">Answer within 24 hours</span>
    <div class="dashboard_table">
        <?php echo Form::open(
        [
        'url'=>route('paypal'),
        'class'=>'physician__form',
        'method'=>"POST",
        'style'=>'position: relative',
        ]); ?>

        <label data-form_question_label = '1'>Your Question</label>
        <input data-form_question_input = '1' type="text" name="question" readonly  value="<?php echo $question; ?>" maxlength="120">
        <label data-form_question_label = '2'>Description</label>
        <textarea id="counterLow" data-form_question_input = '2' readonly  name="description" placeholder="<?php echo $discription; ?>" maxlength="500"></textarea>
        <label data-form_question_label = '3' >Email</label>
        <input data-form_question_input = '3' readonly  style="width: 100%; margin-bottom: 15px" type="email" name="email" value="<?php echo $email; ?>">
        <input type= "hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="HM4534KQESTV8">
        <input type="hidden" name="business" value="kruhlov_1-facilitator@ukr.net">
        <input type="hidden" name="no_shipping" value="1">
        <input type="hidden" name="return" value="http://lara.galactika-it.ru/ipn.php">
        <input type="hidden" name="currency_code" value="USD">
        <input type="hidden" name="lc" value="US">
        <input type="hidden" name="bn" value="PP-BuyNowBF">
        <input type="hidden" name="custom" value="<?php echo $question; ?>">
        <input type="hidden" name="item_name" value="<?php echo $email; ?>">
        <a class="payBtn payBtn-a" href="<?php echo e(route('editQuestion',array('question'=>$question,'email'=> $email))); ?>" name="submit">Go back</a>
        <button type="submit"style="margin-left: 15px" name="submit" class="payBtn">Pay Now</button>
        <?php echo Form::close(); ?>


    </div>
</div>