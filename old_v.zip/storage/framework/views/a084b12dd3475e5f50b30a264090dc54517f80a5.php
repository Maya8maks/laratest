<div class="dashboard__main">
    <div class="dashboard_table_doctor">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__title"><b>Title</b></li>
            <li class="table__time order_time"><b>Remaining time / Time completed</b></li>
            <li class="table__btn"></li>
        </ul>
        <?php $__currentLoopData = $doctor->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul class="table">
                <li class="table__title">
                    <p><?php echo e($answer->question); ?></p>
                </li>
                <?$dateRemaining = Carbon\Carbon::parse( $answer->date_finish)->format('d.M.Y');
                $timeRemaining = Carbon\Carbon::parse($answer->date_finish)->format('H:m');
                $dateCompleted = Carbon\Carbon::parse($answer->date_add)->format('d.M.Y');
                $timeCompleted = Carbon\Carbon::parse($answer->date_add)->format('H:m');
                ?>

                <li class="table__time order_time"><span class="full_hours"><?php echo e($timeRemaining); ?></span><span class="date"><?php echo e($dateRemaining); ?> / </span><span class="full_hours"><?php echo e($timeCompleted); ?></span><span class="date"><?php echo e($dateCompleted); ?></span></li>
                <li class="table__btn"><a  class="doctor_complete" href="#">Complete</a></li>
                <li class="table__questions">
                    <p><?php echo e($answer->description); ?></p>
                </li>
                <li class="table__answer">
                    <p><?php echo e($answer->answer); ?></p>
                </li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>