<div class="dashboard__main">
    <?php echo Form::open(
        [
            'url'=>route('account',array('id'=>$doctor->id)),
            'method'=>'POST',
            'class'=>'dashboard_table account',
            'enctype'=>'multipart/form-data',
        ]); ?>

        <div class="table_title"><h5 >My info</h5> <button class="sbmt" type="submit" name="submit">Submit</button></div>

            <label>Username</label>
            <input type="text" readonly name="user_name" value="<?php echo e($doctor->user_name); ?>">
            <?php if($errors->has('user_name')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('user_name')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Email</label>
            <input type="text" readonly name="email" value="<?php echo e($doctor->email); ?>">
            <?php if($errors->has('email')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Profession</label>
            <input type="text" readonly name="profession"  value="<?php echo e($doctor->profession); ?>">
            <?php if($errors->has('profession')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('profession')); ?></strong>
                </p>
            <?php endif; ?>
            <label>First Name</label>
            <input type="text" readonly name="name" value="<?php echo e($doctor->name); ?>">
            <?php if($errors->has('name')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Last Name</label>
            <input type="text" readonly name="lastName" value="<?php echo e($doctor->lastname); ?>">
            <?php if($errors->has('lastName')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('lastName')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Paypal email</label>
            <input type="text" readonly name="paypal_email" value="<?php echo e($doctor->paypal_email); ?>">
            <?php if($errors->has('paypal_email')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('paypal_email')); ?></strong>
                </p>
            <?php endif; ?>
            <?php if($errors->has('paypal_email')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('country')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Country</label>
            <input type="text"  readonly name="country" value="<?php echo e($doctor->country); ?>">
            <?php if($errors->has('country')): ?>
                <p class="errorMessage">
                    <strong><?php echo e($errors->first('country')); ?></strong>
                </p>
            <?php endif; ?>
            <label>Authorization ID</label>
            <input disabled  name="id" value="<?php echo e($doctor->id); ?>">
            <input hidden  name="id" value="<?php echo e($doctor->id); ?>">
            <label>Status</label>
            <?php echo Form::select('status', array(0 => 'Active', 1=>'Not Active'),$doctor->status );; ?>

    <?php echo Form::close(); ?>

</div>