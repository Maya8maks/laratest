<div class="container">
    <div class="header">
        <div class="header__logo"><a class="logotype" href="index.html"></a></div>
        <div class="header__menu"><a class="menu_items" href="#">Consultant</a><a class="menu_items" href="#">Login</a></div>
    </div>
</div>