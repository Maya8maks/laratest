<ul class="dashboard__menu">
    <li class="dashboard_items"><a class="dashboard_links" href="<?php echo e(route('adminDashboard')); ?>">Dashboard<span>View customer requests</span></a></li>
    <li class="dashboard_items"><a class="dashboard_links" href="<?php echo e(route('adminOrders')); ?>">Orders<span>Manage doctor orders</span></a></li>
    <li class="dashboard_items active_line"><a class="dashboard_links" href="<?php echo e(route('adminCreateAccount')); ?>">Create Account<span>Settings, transactions, and more</span></a></li>
</ul>