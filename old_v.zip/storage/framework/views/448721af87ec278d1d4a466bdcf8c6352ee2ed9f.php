<ul class="dashboard__menu">
    <li class="dashboard_items"><a class="dashboard_links" href="index.html">Dashboard<span>View customer requests</span></a></li>
    <li class="dashboard_items"><a class="dashboard_links" href="index_order.html">My Orders<span>Manage your orders</span></a></li>
    <li class="dashboard_items active_line"><a class="dashboard_links" href="index_account.html">Account<span>Settings, transactions, and more</span></a></li>
</ul>