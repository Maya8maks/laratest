<div class="dashboard__main">
    <div class="dashboard_table">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__title"><b>Title</b></li>
            <li class="table__time"><b>Remaining time</b></li>
            <li class="table__btn"></li>
        </ul>
        <?php $__currentLoopData = $doctor->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($question->status == true): ?>
            <ul class="table">
                <li class="table__title">
                    <p><?php echo e($question->question); ?></p>
                </li>
                <?$date = Carbon\Carbon::parse($question->date_finish)->format('d.M.Y');
                $time = Carbon\Carbon::parse($question->date_finish)->format('H:m')?>

                <li class="table__time"><span class="full_hours"><?php echo e($time); ?></span><span class="date"><?php echo e($date); ?></span></li>
                <li class="table__btn"><a class="complete" href="#">Complete</a></li>
                <li class="table__questions">
                    <p><?php echo e($question->description); ?></p>
                </li>
                <li class="table__answer">
                    <p><?php echo e($question->answer['answer']); ?></p>
                </li>
            </ul>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>