<div class="dashboard__main">
    <div class="dashboard_table">
        <h5 class="table_title">Customer Requests</h5>
        <ul class="table head">
            <li class="table__time" style="text-align: left"><b>Title</b></li>
            <?php if(isset($search)): ?>
                <li class="table__time"><b><a href="<?php echo route('orderBySearch', array('orderBy'=>$orderByDay, 'search'=>$search)); ?>">Remaining time</a></b></li>
            <?php else: ?>
                <li class="table__time"><b><a href="<?php echo route('adminDashboardOrderBy', array('orderBy'=>$orderByDay)); ?>">Remaining time</a></b></li>
            <?php endif; ?>
            <li class="table__time"><b>Email address</b></li>
            <li class="table__time"><b>Status</b></li>
            <?php if(isset($search)): ?>
                <li class="table__time"><b><a href="<?php echo route('orderBySearch', array('orderBy'=>$orderByName, 'search'=>$search)); ?>">Consultant</a></b></li>
            <?php else: ?>
                <li class="table__time"><b><a href="<?php echo route('adminDashboardOrderBy', array('orderBy'=>$orderByName)); ?>">Consultant</a></b></li>
            <?php endif; ?>
            <li class="table__btn"></li>
        </ul>
        <?php if(isset($questions)): ?>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="table">
                    <li class="table__time" style="text-align: left">
                        <p><?php echo e($question->question); ?></p>
                    </li>
                    <?  $timeDifferent = Carbon\Carbon::now()->diffInMinutes(Carbon\Carbon::parse($question->date_add));
                        $hours = floor($timeDifferent/60);
                        $minutes = $timeDifferent - ($hours*60)
                    ?>
                    <li class="table__time">
                        <span class="hours">
                            <?php echo 24-($hours+1); ?> hours
                        </span>
                        <span class="min">
                            <?php echo 60 - $minutes; ?> min
                        </span>
                    </li>
                    <li  class="table__time">
                        <p><?php echo $question->user_email; ?></p>
                    </li>
                    <li  class="table__time">
                        <?php if($question->status == 0): ?>
                            <p>Open</p>
                        <?php elseif($question->status == 1): ?>
                            <p>Complete</p>
                        <?php else: ?>
                            <p>In Progress</p>
                        <?php endif; ?>
                    </li>
                    <li  class="table__time">
                        <p><?php echo $question->doctorName($question->user_id); ?></p>
                    </li>
                    <li class="table__btn">
                        <?php if($question->status == 1): ?>
                            <a class="complete" href="#">Complete</a>
                        <?php else: ?>
                            <a class="fade_btn btn_answer" href="#">Answer</a>
                        <?php endif; ?>
                    </li>
                    <?php if($question->status == 1): ?>
                        <li class="table__questions">
                            <p><?php echo e($question->description); ?></p>
                        </li>
                        <li class="table__answer">
                            <p><?php echo e($question->answer); ?><
                    <?php else: ?>
                        <li class="table__text">
                            <p><?php echo e($question->description); ?></p>
                        </li>
                    <?php endif; ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<div>
    <ul class="table">
    <li  class="table__btn" style="width: 100%; padding-top:  10px; padding-left: 10px">
        <?php echo Form::open(
            [
                'url'=>route('search'),
                'class'=>'physician__form',
                'method'=>'POST',
                'enctype'=>'multipart/form-data',
                'style'=>'position: relative'
            ]); ?>

        <input type="text" name="search_Text" placeholder="Search Text">
        <input style="width: 100%; margin-left: 0" type="submit" value="submit" name="submit" >
        <?php echo Form::close(); ?>

    </li>
    <li  class="table__btn" style="width: 100%; padding-top:  40px; padding-left: 10px">
        <a class="btn_answer" href="<?php echo e(route('adminDashboard')); ?>">All</a>
    </li>
    <li class="table__btn" style="width: 100%; padding-top:  10px; padding-left: 10px">
        <a class="btn_answer" href="<?php echo e(route('adminDashboardOrderByStatus', array('status'=>'open'))); ?>">
            Open
        </a>
    </li>
    <li class="table__btn" style="width: 100%; padding-top: 10px; padding-left: 10px">
       <a class="btn_answer" href="<?php echo e(route('adminDashboardOrderByStatus', array('status'=>'in_progress'))); ?>">
           In Progress
       </a>
    </li>
    <li class="table__btn" style="width: 100%; padding-top:  10px; padding-left: 10px">
        <a class="btn_answer" href="<?php echo e(route('adminDashboardOrderByStatus', array('status'=>'complete'))); ?>">
            Complete
        </a>
    </li>
    </ul>
</div>