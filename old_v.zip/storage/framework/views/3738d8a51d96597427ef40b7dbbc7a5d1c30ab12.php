<div class="container">
    <button class="burger"><i class="fas fa-bars"></i></button>
    <div class="header">
        <div class="header__logo"><a class="logotype" href="<?php echo route('main'); ?>"></a></div>
        <div class="header__btn"><a class="menu_items" href="<?php echo route('logoutUser'); ?>">Logout</a></div>
    </div>
    <?php if(isset($dashboard)): ?>
        <button class="dots"><i class="fas fa-ellipsis-v"></i></button>
    <?php endif; ?>
</div>