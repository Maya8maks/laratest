<h3>Hello our specialist Doctor <?php echo $data['doctor_name']; ?> <?php echo $data['doctor_lastName']; ?>.</h3>
<h3>Answer for your question : Some question.</h3>
<br>
<h3><p>Answer:</p>
    <p><?php echo $data['answer']; ?></p>
</h3>